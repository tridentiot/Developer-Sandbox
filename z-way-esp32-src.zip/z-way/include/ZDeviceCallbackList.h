//
//  ZDeviceCallbackList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/21/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_device_callback_list_h
#define zway_device_callback_list_h

struct _ZDeviceCallbackListEntry
{
    ZDeviceCallback callback;
    void *arg;
    ZWDeviceChangeType mask;
    ZDeviceCallbackListEntry next;
};

struct _ZDeviceCallbackList 
{
    ZDeviceCallbackListEntry first;
    ZDeviceCallbackListEntry last;
};

ZDeviceCallbackList _zway_device_callback_list_create();

void _zway_device_callback_list_free(const ZWay zway, ZDeviceCallbackList list);

void _zway_device_callback_list_add(const ZWay zway, ZDeviceCallbackList list, ZWDeviceChangeType mask, ZDeviceCallback callback, void *arg);

void _zway_device_callback_list_remove(const ZWay zway, ZDeviceCallbackList list, ZDeviceCallback callback);

void _zway_device_callback_list_add_ex(const ZWay zway, ZDeviceCallbackList list, ZWDeviceChangeType mask, ZDeviceCallback callback, void *arg);

void _zway_device_callback_list_remove_ex(const ZWay zway, ZDeviceCallbackList list, ZDeviceCallback callback, void *arg);

ZWEXPORT_PRIVATE void _zway_device_callback_list_notify(const ZWay zway, ZWDeviceChangeType mask, ZDeviceCallback callback, void *arg);

#endif
