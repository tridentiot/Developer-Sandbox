//
//  ZJobCallbackList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/12/13.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_job_callback_list_h
#define zway_job_callback_list_h

struct _ZJobCallbackListEntry
{
    ZJobCustomCallback success_callback;
    ZJobCustomCallback failure_callback;
    void *arg;
    ZJobCallbackListEntry next;
};

void _zway_job_callback_list_add(ZJob job, ZJobCustomCallback success_callback, ZJobCustomCallback failure_callback, void* arg);

void _zway_job_callback_list_free(ZJob job);

void _zway_job_callback_list_transfer(ZJob from, ZJob to);

#endif
