//
//  ZDataExtPrivate.h
//  z-way
//
//  Created by Alex Skalozub on 11/03/14.
//
//  Copyright (c) 2014 Z-Wave.Me
//

#ifndef zdata_ext_private_h
#define zdata_ext_private_h

ZDataHolder _zway_find_instance_cc_data(const ZWay zway, const ZDevice device, ZWBYTE instance_id, ZWBYTE cc_id, const char *path);
ZDataHolder _zway_find_cc_data(const ZWay zway, const ZInstance instance, ZWBYTE cc_id, const char *path);

static inline ZWError _zway_find_controller_and_set_integer(const ZWay zway, const ZWCSTR path, const int value)
{
    return _zdata_find_and_set_integer(zway->controller, path, value);
};
static inline ZWError _zway_find_controller_and_set_integer_read_only(const ZWay zway, const ZWCSTR path, const int value)
{
    return _zdata_find_and_set_integer_read_only(zway->controller, path, value);
}
static inline ZWError _zway_find_controller_and_set_boolean(const ZWay zway, const ZWCSTR path, const ZWBOOL value)
{
    return _zdata_find_and_set_boolean(zway->controller, path, value);
};
static inline ZWError _zway_find_controller_and_set_boolean_read_only(const ZWay zway, const ZWCSTR path, const ZWBOOL value)
{
    return _zdata_find_and_set_boolean_read_only(zway->controller, path, value);
}
static inline ZWError _zway_find_controller_and_set_empty(const ZWay zway, const ZWCSTR path)
{
    return _zdata_find_and_set_empty(zway->controller, path);
};

static inline ZWError _zway_find_controller_and_set_binary_allocated(const ZWay zway, const ZWCSTR path, ZWBYTE *const value, const size_t count) // This function can free the value in some cases, so the caller MUST NOT use it after giving to this function
{
    return _zdata_find_and_set_binary_allocated(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_binary_copy(const ZWay zway, const ZWCSTR path, const ZWBYTE *const value, const size_t count)
{
    return _zdata_find_and_set_binary_copy(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_binary_copy_read_only(const ZWay zway, const ZWCSTR path, const ZWBYTE *const value, const size_t count)
{
    return _zdata_find_and_set_binary_copy_read_only(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_binary_static(const ZWay zway, const ZWCSTR path, const ZWBYTE *const value, const size_t count)
{
    return _zdata_find_and_set_binary_static(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_binary_null(const ZWay zway, const ZWCSTR path)
{
    return _zdata_find_and_set_binary_null(zway->controller, path);
};

static inline ZWError _zway_find_controller_and_set_integer_array_allocated(const ZWay zway, const ZWCSTR path, int *const value, const size_t count) // This function can free the value in some cases, so the caller MUST NOT use it after giving to this function
{
    return _zdata_find_and_set_integer_array_allocated(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_integer_array_copy(const ZWay zway, const ZWCSTR path, const int *const value, const size_t count)
{
    return _zdata_find_and_set_integer_array_copy(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_integer_array_static(const ZWay zway, const ZWCSTR path, const int *const value, const size_t count)
{
    return _zdata_find_and_set_integer_array_static(zway->controller, path, value, count);
};
static inline ZWError _zway_find_controller_and_set_integer_array_null(const ZWay zway, const ZWCSTR path)
{
    return _zdata_find_and_set_integer_array_null(zway->controller, path);
};

static inline ZWError _zway_find_controller_and_set_string_allocated(const ZWay zway, const ZWCSTR path, const ZWSTR value) // This function can free the value in some cases, so the caller MUST NOT use it after giving to this function
{
    return _zdata_find_and_set_string_allocated(zway->controller, path, value);
};
static inline ZWError _zway_find_controller_and_set_string_copy(const ZWay zway, const ZWCSTR path, const ZWCSTR value)
{
    return _zdata_find_and_set_string_copy(zway->controller, path, value);
};
static inline ZWError _zway_find_controller_and_set_string_copy_read_only(const ZWay zway, const ZWCSTR path, const ZWCSTR value)
{
    return _zdata_find_and_set_string_copy_read_only(zway->controller, path, value);
}
static inline ZWError _zway_find_controller_and_set_string_static(const ZWay zway, const ZWCSTR path, const ZWCSTR value)
{
    return _zdata_find_and_set_string_static(zway->controller, path, value);
};
static inline ZWError _zway_find_controller_and_set_string_null(const ZWay zway, const ZWCSTR path)
{
    return _zdata_find_and_set_string_null(zway->controller, path);
};

static inline int _zway_find_controller_and_get_integer(const ZWay zway, const ZWCSTR path, const int default_value)
{
    return _zdata_find_and_get_integer(zway->controller, path, default_value);
};
static inline ZWError _zway_find_controller_and_get_binary(const ZWay zway, const ZWCSTR path, const ZWBYTE **const value, size_t *const count)
{
    return _zdata_find_and_get_binary(zway->controller, path, value, count);
};
static inline ZWBOOL _zway_find_controller_and_get_boolean(const ZWay zway, const ZWCSTR path, const ZWBOOL default_value)
{
    return _zdata_find_and_get_boolean(zway->controller, path, default_value);
};
static inline ZWCSTR _zway_find_controller_and_get_string(const ZWay zway, const ZWCSTR path, const ZWCSTR default_value)
{
    return _zdata_find_and_get_string(zway->controller, path, default_value);
};
static inline ZWBOOL _zway_find_controller_and_is_empty(const ZWay zway, const ZWCSTR path)
{
    return _zdata_find_and_is_empty(zway->controller, path);
};

static inline ZDataHolder _zway_get_controller(const ZWay zway)
{
    return zway->controller;
};

ZWBOOL _zway_find_device_and_get_boolean(const ZWay zway, const ZWNODE device_id, const ZWCSTR path, const ZWBOOL default_value);
ZWError _zway_find_device_and_set_boolean(const ZWay zway, const ZWNODE device_id, const ZWCSTR path, const ZWBOOL value);
ZWError _zway_find_device_and_set_integer(const ZWay zway, const ZWNODE device_id, const ZWCSTR path, const int value);

ZWBOOL _zway_find_device_instance_cc_get_boolean(const ZWay zway, const ZWNODE device_id, const ZWBYTE instance_id, const ZWBYTE cc_id, const ZWCSTR path, const ZWBOOL default_value);

#endif
