//
//  ZDDXPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_zddx_private_h
#define zway_zddx_private_h

#include "ZPlatform.h"
#include "ZArchivePrivate.h"
#include "ZDataExtPrivate.h"

typedef struct _ZWayZddxConfigRestoreNodeList_s
{
    ZWBYTE protocolSpecific[3];
    ZWBYTE genericType;
    ZWBYTE specificType;
} _ZWayZddxConfigRestoreNodeList_t;

typedef struct _ZWayZddxConfigRestore_s
{
    ZWDWORD homeId;
    ZWNODE nodeId;
    ZWBYTE maxNodeId;
    _ZWayZddxConfigRestoreNodeList_t devices[NODE_MAX];
} _ZWayZddxConfigRestore_t;

ZWError _zddx_zway_init(const ZWay zway, const ZWCSTR config_dir);
static inline void _zddx_zway_deinit(const ZWay zway)
{
    return _zddx_operations_deinit(&zway->ctx_zddx);
}
static inline ZWBOOL _zddx_zway_is_loaded(const ZWay zway)
{
    return _zddx_operations_is_loaded(&zway->ctx_zddx);
}
static inline void _zddx_zway_reset_loaded_status(const ZWay zway)
{
    return _zddx_operations_reset_loaded_status(&zway->ctx_zddx);
}
static inline ZWCSTR _zddx_zway_get_config_dir(const ZWay zway)
{
    return _zddx_operations_get_config_dir(&zway->ctx_zddx);
}
static inline ZWError _zddx_zway_backup(const ZWay zway, const _ZStreamWriter_t *const stream, void *const ctx_stream, const _ZddxOperationsConfigFilterHelper_t *const filter, const size_t count)
{
    return _zddx_operations_backup(&zway->ctx_zddx, stream, ctx_stream, filter, count);
}
static inline ZWError _zddx_zway_restore(const ZWay zway, const _ZStreamReader_t  *const stream, void *const ctx_stream, const _ZddxOperationsConfigFilterHelper_t *const filter, const size_t count, const ZWBOOL full)
{
    return _zddx_operations_restore(&zway->ctx_zddx, stream, ctx_stream, filter, count, full);
}
static inline ZWBOOL _zddx_zway_is_restore_info(const ZWay zway)
{
    return _zddx_operations_is_restore_info(&zway->ctx_zddx);
}
static inline void _zddx_zway_reset_restore_info(const ZWay zway)
{
    return _zddx_operations_reset_restore_info(&zway->ctx_zddx);
}
ZWError _zddx_zway_restore_read_config(const ZWay zway, _ZWayZddxConfigRestore_t **const p_result);

ZWError _zddx_save_device_without_lock(const ZWay zway, const ZDevice device);
static inline ZWError _zddx_save_controller_without_lock(const ZWay zway)
{
    return _zddx_operations_save_controller(&zway->ctx_zddx);
}
void _zddx_remove_node_without_lock(const ZWay zway, const ZWNODE node_id);
static inline ZWError _zddx_zway_operations_file_open_tmp(const ZWay zway, ZW_FILE_HANDLE *const p_fd, ZWSTR *const p_path, const ZWDWORD mode)
{
    return _zddx_operations_file_open_tmp(&zway->ctx_zddx, p_fd, p_path, mode);
}

static inline void _zddx_load_from_xml(const ZWay zway)
{
    (void)_zddx_operations_load(&zway->ctx_zddx);
}

static inline _ZddxOperationsConfigCtx_t *_zddx_zway_operations_get_ctx(const ZWay zway)
{
    return &zway->ctx_zddx;
}

#endif // zway_zddx_private_h
