//
//  ZDeviceInstanceList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/30/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_instance_list_h
#define zway_instance_list_h

struct _ZInstanceListEntry
{
    ZInstance instance;
    ZInstanceListEntry next;
};

struct _ZInstanceList
{
    ZInstanceListEntry first;
    ZInstanceListEntry last;
    size_t count;
    ZTIME_T update_time;
};

// create a new device instance list
ZInstanceList _zway_instance_list_create();

// deallocate device instance list and all its members
void _zway_instance_list_free(const ZWay zway, ZInstanceList list);

// add a new instance to device instance list
void _zway_instance_list_append(const ZWay zway, ZInstanceList list, ZInstance instance);

// remove instance from device instance list (by pointer)
void _zway_instance_list_remove(const ZWay zway, ZInstanceList list, ZInstance instance);

// remove instance from device instance list (by id)
void _zway_instance_list_remove_by_id(const ZWay zway, ZInstanceList list, ZWBYTE id);

// remove all non-default (id != 0) instances from list
void _zway_instance_list_remove_non_default(const ZWay zway, ZInstanceList list);

// return a device instance pointer for specified id, or NULL if not found
ZInstance _zway_instance_list_get_by_id(const ZWay zway, const ZInstanceList list, ZWBYTE id);


#endif
