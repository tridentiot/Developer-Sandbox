//
//  ZCommand.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/4/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_command_h
#define zway_command_h

struct _ZCommand 
{
    // TODO: Command Class Id can be WORD if first byte is in range 0xf1-0xff
    ZWBYTE id;
    ZInstance instance;
    const ZCommandClass *cc;
    ZDataHolder data;
    float timer_left;
};

// deallocate a command and free all associated resources
void _zway_command_free(const ZWay zway, ZCommand command);

// create a new command object
// NULL == allocation error
ZCommand _zway_command_create(const ZWay zway, const ZInstance instance, ZWBYTE id);

void _zway_command_attach_callbacks(const ZWay zway, ZCommand command);

// starts interview for a command
void _zway_command_do_interview(const ZWay zway, ZCommand command);

// invalidates interview for a command
void _zway_command_interview_invalidate(const ZWay zway, ZCommand command);

// shortcuts for reading interviewDone and interviewCounter
ZWBOOL _zway_command_interview_done(const ZWay zway, const ZCommand command);
int _zway_command_interview_counter(const ZWay zway, const ZCommand command);
void _zway_command_set_interview_done(const ZWay zway, ZCommand command);
ZWBOOL _zway_command_supported(const ZWay zway, const ZCommand command);

// returns command class version
int _zway_command_version(const ZWay zway, const ZCommand command);

// checks if command class is in NIF
ZWBOOL _zway_command_in_nif(const ZWay zway, const ZDevice device, ZWBYTE cc_id);
ZWBOOL _zway_command_in_instance_nif(const ZWay zway, const ZInstance instance, const ZWBYTE cc_id);
ZWBOOL _zway_command_in_nif_ex(const ZWay zway, const ZDataHolder nifDH, ZWBYTE cc_id, ZWBOOL check_controlled);

// restarts internal command class timer
void _zway_command_timer_reset(const ZWay zway, ZCommand command);
void _zway_command_timer_reset_to_value(const ZWay zway, ZCommand command, float timeout);

#endif
