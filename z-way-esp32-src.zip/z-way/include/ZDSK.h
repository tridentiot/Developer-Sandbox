//
//  ZDSK.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 2/14/25.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_dsk_h
#define zway_dsk_h

#include "ZDefsPrivate.h"
#include "ZS2.h"

#define ZWAY_DSK_LENGTH 16
#define ZWAY_DSK_ZWS2DSK "zws2dsk:" // AWG: RT:00.12.0007.1 - 8.2.10.2.3 QR Code scanning capability


#if ZWAY_DSK_LENGTH >= SECURITY_S2_PRIVATE_KEY_LENGTH
#error "ZWAY_DSK_LENGTH >= SECURITY_S2_PRIVATE_KEY_LENGTH!!"
#endif

// dsk should be a pre-allocated by the caller size bytes array
ZWEXPORT ZWBOOL zway_dsk_string_to_bytes(ZWCSTR dsk_string, ZWBYTE *dsk, size_t size);

// returns allocated string
ZWEXPORT ZWSTR zway_dsk_bytes_to_string(const ZWBYTE *dsk, size_t size);

// the possibility that the buffer will overflow is not checked
ZWEXPORT_PRIVATE void _zway_dsk_bytes_fill_string_unsafe(const ZWBYTE *dsk, size_t size, ZWSTR dsk_dst);

// fills the pre-allocated dsk and data with the content from qr_string
ZWEXPORT ZWBOOL zway_dsk_qr_string_to_node_provisioning(ZWLog logger, ZWCSTR qr_string, ZWBYTE *dsk, size_t size, NodeProvisioningData *data);

#endif