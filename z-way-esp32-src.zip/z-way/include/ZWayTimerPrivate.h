//
//  ZWayTimerPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//
//  Copyright (c) 2021 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//
#ifndef zway_timer_private_h
#define zway_timer_private_h

#include "ZTimerPrivate.h"
#include "ZDefsPrivate.h"
#include "ZWayPrivate.h"
#include "ZWayLib.h"

typedef void (*_ZWayTimerCallback)(const ZWay zway, void *const arg);

static inline ZWError _zway_timer_init(const ZWay zway)
{
    return _ztimer_init(&zway->ctx_timers, zway_get_logger(zway), zway);
};
static inline void _zway_timer_deinit(const ZWay zway)
{
    if (zway->ctx_timers != NULL)
    {
        _ztimer_deinit(zway->ctx_timers);
        zway->ctx_timers = NULL;
    }
};
static inline ZWError _zway_timer_add_ex(const ZWay zway, const ZWDWORD timeout_ms, _ZTimer_t **const p_timer, const _ZWayTimerCallback callback, const _ZWayTimerCallback cancelCallback, void *const arg)
{
    return _ztimer_create(zway->ctx_timers, p_timer, timeout_ms, arg, (_ZTimerCallback)callback, (_ZTimerCallback)cancelCallback);
};
static inline ZWError _zway_timer_add(const ZWay zway, const ZWDWORD timeout_ms, _ZTimer_t **const p_timer, const _ZWayTimerCallback callback, void *const arg)
{
    return _ztimer_create(zway->ctx_timers, p_timer, timeout_ms, arg, (_ZTimerCallback)callback, NULL);
};
static inline ZWError _zway_timer_remove(const ZWay zway, _ZTimer_t *const timer)
{
    return _ztimer_remove(zway->ctx_timers, timer);
};
static inline ZWError _zway_timer_fire(const ZWay zway, _ZTimer_t *const timer)
{
    return _ztimer_fire(zway->ctx_timers, timer);
};
static inline void _zway_timer_loop(const ZWay zway)
{
    return _ztimer_loop(zway->ctx_timers);
};

#endif // zway_timer_private_h
