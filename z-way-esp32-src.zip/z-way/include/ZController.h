//
//  ZController.h
//  Part of Z-Way.C library
//
//  Created by Poltorak Serguei on 9/25/17.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2017 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_controller_h
#define zway_controller_h

#include "ZStreamPrivate.h"

typedef enum _SecureInterviewDecision {
    DONT_DO_SECURE_INTERVIEW,
    DO_SECURE_INTERVIEW,
    INFORM_SIS_TO_DO_SECURE_INTERVIEW
} SecureInterviewDecision;

void _zway_controller_inform_about_suc_callback(const ZWay zway, const ZWBYTE funcId, void *const arg);
void _zway_controller_remove_cc_from_nif(ZWBYTE *nif_buffer, ZWBYTE *nif_count, ZWBYTE cc_id);
void _zway_node_provisioning_dsk_disable_device_entry(const ZWay zway, ZWNODE nodeId);
ZDataHolder _zway_provisioning_dsk_get_by_string(const ZWay zway, ZWCSTR dskString);
ZDataHolder _zway_provisioning_dsk_get_by_bytes(const ZWay zway, ZWBYTE dskLength, const ZWBYTE *dsk);

// for Inclusion Controller CC and Secure S0/S2 interview
ZWNODE _zway_get_sis_id(ZWay zway);
ZCommand _zway_should_sis_handle_security(ZWay zway);
ZWBOOL _zway_inform_sis_about_security_interview_abandon(ZWay zway);
SecureInterviewDecision _zway_controller_should_initiate_secure_interview(ZWay zway, ZWNODE nodeId);

ZWEXPORT_PRIVATE ZWError _zway_controller_config_save_stream(const ZWay zway, const _ZStreamWriter_t *const stream, void *const ctx_stream);
ZWEXPORT_PRIVATE ZWError _zway_controller_config_restore_stream(const ZWay zway, const ZWBOOL full, const _ZStreamReader_t *const stream, void *const ctx_stream);

ZWEXPORT_PRIVATE ZWError _zway_controller_config_save_file(const ZWay zway, const ZWCSTR path);
ZWEXPORT_PRIVATE ZWError _zway_controller_config_restore_file(const ZWay zway, const ZWCSTR path, const ZWBOOL full);

#endif
