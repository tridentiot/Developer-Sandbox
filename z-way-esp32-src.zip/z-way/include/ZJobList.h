//
//  ZJobList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/25/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_job_list_h
#define zway_job_list_h

struct _ZJobListEntry 
{
    ZJob job;
    ZJobListEntry next;
};

struct _ZJobList
{
    ZJobListEntry first;
    ZJobListEntry last;
    size_t count;
    ZWBOOL tracking;
};

ZJobList _zway_job_list_create(ZWBOOL tracking);
void _zway_job_list_free(ZJobList list);
void _zway_job_list_append(ZJobList list, ZJob job);
void _zway_job_list_remove(ZJobList list, ZJob job);

void _zway_job_list_set_tracked(ZJobList list);
void _zway_job_list_set_untracked(ZJobList list);

ZJobList _zway_job_list_filter(const ZJobList list, ZJobListFilter filter); 
size_t _zway_job_list_count(const ZJobList list, ZJobListFilter filter);

#endif
