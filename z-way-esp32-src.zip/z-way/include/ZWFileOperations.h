//
//  ZWFileOperations.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.

#ifndef zway_file_operations_h
#define zway_file_operations_h

static inline ZWError _zway_rename_file(const ZWay zway, ZWCSTR src_path, ZWCSTR dst_path)
{
    return (_zfile_rename(_zway_get_logger(zway), src_path, dst_path));
}
static inline ZWError _zway_remove_file(const ZWay zway, ZWCSTR file_path)
{
    return (_zfile_remove(_zway_get_logger(zway), file_path));
}

#endif//zway_file_operations_h
