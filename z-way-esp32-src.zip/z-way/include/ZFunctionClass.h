//
//  ZFunctionClass.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/11/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_function_class_h
#define zway_function_class_h

struct _ZFunctionClass {
    ZWBYTE id;
    ZWCSTR name;
    ZWCSTR description;
    ZFunctionClassResponse responseFunc;
    ZFunctionClassCallback callbackFunc;
    ZFunctionClassAck ackFunc;
    ZFunctionClassTimeout timeoutFunc;
    ZWBOOL urgent:1;
    ZWBOOL block:1;    
    ZWBOOL allow_duplicate:1;    
    ZWBOOL sleeping_check:1;
    ZWBOOL security:1;
    ZWBOOL has_node:1;
    ZWBOOL send_to_node:1;
    
    // additional timeouts
    float timeout_response;
    float timeout_callback_first;
    float timeout_callback_more;
};

// returns a known function class by id
const ZFunctionClass * _zway_get_function_by_id(ZWBYTE id);
// returns a known function class by name
const ZFunctionClass * _zway_get_function_by_name(ZWCSTR name);

// checks if function class is supported
ZWBOOL _zway_fc_supported(const ZWay zway, ZWBYTE id);

// returns a supported function class, or NULL if not supported
const ZFunctionClass * _zway_get_supported_function_by_id(const ZWay zway, ZWBYTE id);

ZJob _zway_fc_create_job(const ZWay zway, const ZFunctionClass *fc, ZWBYTE payload_size, const ZWBYTE *payload, ZJobCustomCallback on_success, ZJobCustomCallback on_failure, void* arg, ZWCSTR description);

#endif
