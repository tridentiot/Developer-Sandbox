//
//  ZDDXTransform.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 4/11/23.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2023 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_zddx_transform_h
#define zway_zddx_transform_h

ZWError _zway_zddx_transform(ZWay zway, ZWCSTR path);

#endif
