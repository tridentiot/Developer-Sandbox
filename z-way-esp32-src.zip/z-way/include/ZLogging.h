//
//  ZLogging.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 11/03/14.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_logging_h
#define zway_logging_h

#include "ZLog.h"
#include "ZDefsPublic.h"
#include "ZWayLib.h"

ZWEXPORT void zway_log(const ZWay zway, ZWLogLevel level, ZWCSTR message, ...) __printflike(3, 4);
ZWEXPORT void zway_dump(const ZWay zway, ZWLogLevel level, ZWCSTR prefix, size_t length, const ZWBYTE *buffer);
ZWEXPORT void zway_log_error(const ZWay zway, ZWLogLevel level, ZWCSTR message, ZWError error);

ZWEXPORT ZWError _zway_log_error_short_size(const ZWay zway, const ZWCSTR where, const size_t expected, const size_t actual);

#endif
