//
//  ZInstance.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/30/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_instance_h
#define zway_instance_h

struct _ZInstance
{
    ZWBYTE id;
    ZDevice device;
    ZDataHolder data;
    ZCommandList commands;
};

// deallocate a device instance pointer and free all associated resources
void _zway_instance_free(const ZWay zway, ZInstance instance);

// create a new device instance object
// NULL == allocation error
ZInstance _zway_instance_create(const ZWay zway, const ZDevice device, ZWBYTE id);

// checks if CC is present for this instance
ZWBOOL _zway_instance_is_command_present(const ZWay zway, const ZInstance instance, ZWBYTE id);

// checks if CC is supported for this instance
ZWBOOL _zway_instance_is_command_supported(const ZWay zway, const ZInstance instance, ZWBYTE id);

// returns a CC by id for this instance
ZCommand _zway_instance_get_command(const ZWay zway, const ZInstance instance, ZWBYTE id);

#endif
