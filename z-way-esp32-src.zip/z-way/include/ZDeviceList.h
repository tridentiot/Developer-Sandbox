//
//  ZDeviceList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/30/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_device_list_h
#define zway_device_list_h

struct _ZDeviceListEntry
{
    ZDevice device;
    ZDeviceListEntry next;
};

struct _ZDeviceList
{
    ZDeviceListEntry first;
    ZDeviceListEntry last;
    size_t count;
    ZTIME_T update_time;
};

// create a new device list
ZDeviceList _zway_device_list_create();

// deallocate device list and all its members
void _zway_device_list_free(const ZWay zway, ZDeviceList list);

// add a new device to device list
void _zway_device_list_append(const ZWay zway, ZDeviceList list, ZDevice device);

// remove device from device list (by id)
void _zway_device_list_remove_by_id(const ZWay zway, ZDeviceList list, ZWNODE id);

// return a device pointer for specified id, or NULL if not found
ZDevice _zway_device_list_get_by_id(const ZWay zway, const ZDeviceList list, ZWNODE id);

#endif
