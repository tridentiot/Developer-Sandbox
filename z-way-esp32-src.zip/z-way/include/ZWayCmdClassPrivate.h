//
//  ZWayCmdClassPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//


#ifndef zway_cmd_class_private_h
#define zway_cmd_class_private_h

#define COMMAND_CLASS_APPLICATION_STATUS 0x22
#define COMMAND_CLASS_CLIMATE_CONTROL_SCHEDULE 0x46
#define COMMAND_CLASS_TRANSPORT_SERVICE 0x55
#define COMMAND_CLASS_CRC_16_ENCAP 0x56
#define COMMAND_CLASS_ASSOCIATION_GRP_INFO 0x59
#define COMMAND_CLASS_MULTI_CHANNEL 0x60
#define COMMAND_CLASS_DEVICE_RESET_LOCALLY 0x5A
#define COMMAND_CLASS_CENTRAL_SCENE 0x5B
#define COMMAND_CLASS_ZWAVEPLUS_INFO 0x5E
#define COMMAND_CLASS_SUPERVISION 0x6C
#define COMMAND_CLASS_MANUFACTURER_SPECIFIC 0x72
#define COMMAND_CLASS_POWERLEVEL 0x73
#define COMMAND_CLASS_INCLUSION_CONTROLLER 0x74
#define COMMAND_CLASS_NODE_NAMING 0x77
#define COMMAND_CLASS_FIRMWARE_UPDATE_MD 0x7A
#define COMMAND_CLASS_CLOCK 0x81
#define COMMAND_CLASS_ASSOCIATION 0x85
#define COMMAND_CLASS_VERSION 0x86
#define COMMAND_CLASS_INDICATOR 0x87
#define COMMAND_CLASS_TIME 0x8A
#define COMMAND_CLASS_MULTI_CHANNEL_ASSOCIATION 0x8E
#define COMMAND_CLASS_MULTI_CMD 0x8F
#define COMMAND_CLASS_SECURITY 0x98
#define COMMAND_CLASS_SECURITY_2 0x9F

#endif // zway_cmd_class_private_h