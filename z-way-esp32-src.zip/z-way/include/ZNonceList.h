//
//  ZNonceList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/1/13.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef z_way_nonce_list_h
#define z_way_nonce_list_h

#define SECURITY_NONCE_LIFE_TIME	1000 // 10s in 10ms ticks
#define SECURITY_ENC_MSG_LIFE_TIME	200  //  2s in 10ms ticks

struct _ZNonce {
    ZWBYTE key[8];
    ZWBOOL valid;
    int timestamp;
};

struct _ZNonceListEntry
{
    struct _ZNonce nonce;
    ZNonceListEntry next;
};

struct _ZNonceList
{
    ZNonceListEntry first;
};

ZWBOOL _zway_nonce_is_valid(const ZWay zway, const ZNonce nonce);

void _zway_nonce_invalidate(const ZWay zway, ZNonce nonce);

ZNonceList _zway_nonce_list_create();

void _zway_nonce_list_free(ZNonceList list);

ZNonce _zway_nonce_list_append(const ZWay zway, const ZWBYTE *data);

/* unused
void _zway_nonce_list_remove(const ZWay zway, ZNonce nonce);

void _zway_nonce_list_remove_by_id(const ZWay zway, ZWBYTE id);
*/

ZNonce _zway_nonce_list_get_by_id(const ZWay zway, ZWBYTE id);

ZNonce _zway_nonce_lookup(const ZWay zway, ZWBYTE id);

#endif
