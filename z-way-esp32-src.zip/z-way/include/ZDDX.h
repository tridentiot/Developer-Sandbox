//
//  ZDDX.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/4/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_zddx_h
#define zway_zddx_h

#include "ZDDXmlPrivate.h"
#include "ZFileOperationsPrivate.h"

#define ZWAY_ZDDX_PATH_S2_KNOWN_DSK Z_ZDDX_OPERATIONS_PATH Z_FILE_PATH_SEPARATOR_STR "known_dsk"
#define ZWAY_ZDDX_PATH_S2_KEY_PAIR Z_ZDDX_OPERATIONS_PATH Z_FILE_PATH_SEPARATOR_STR "s2_key_pair"

#define CURRENT_SHIFT 100

ZWError _zddx_delete_xml(ZWay zway);

ZWError _zddx_get_configuration(const ZWay zway, ZDevice device);

ZGuessedProduct* _zddx_guess_xml(const ZWay zway, ZDevice device);

void _zddx_guess_free(ZGuessedProduct *products);
#endif
