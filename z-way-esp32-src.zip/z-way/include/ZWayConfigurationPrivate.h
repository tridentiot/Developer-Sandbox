#ifndef zway_configuration_privat_h
#define zway_configuration_privat_h

#include "ZWay.h"
#include "ZCommandClass.h"
#include "ZXmlLookup.h"
#include "ZLogging.h"

ZWError _zway_configuration_check_folder(ZWLog logger, ZWCSTR *p_translations_folder, ZWCSTR *p_zddx_folder);
ZWError _zway_configuration_init(ZWay zway, ZWCSTR translations_folder, ZWCSTR zddx_folder);
void _zway_configuration_deinit(ZWay zway);

ZWBYTE _zway_configuration_get_defaults_controller_command_class_supported_version(ZWay zway, const ZCommandClass *cc);
ZWSTR _zway_configuration_get_thermostat_setpoint_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_thermostat_fan_mode_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_thermostat_mode(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_meter_type_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_sensor_multilevel_type_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_sensor_binary_type_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_configuration_get_meter_scale_name(ZWay zway, ZWBYTE id, ZWBYTE scale);
ZWSTR _zway_configuration_get_sensor_multilevel_scale_name(ZWay zway, ZWBYTE id, ZWBYTE scale);

ZWSTR _zway_lookup_manufacturer_name(ZWay zway, int id);
ZWSTR _zway_lookup_sdk_name(ZWay zway, const char *version);
ZWSTR _zway_lookup_device_type_string(ZWay zway, ZWBYTE generiType, ZWBYTE specificType);
ZWSTR _zway_lookup_aec_meter_name(ZWay zway, ZWBYTE meterId);
ZWSTR _zway_lookup_aec_scale_name(ZWay zway, ZWBYTE meterId, ZWBYTE scaleId);
ZWSTR _zway_lookup_aec_status_name(ZWay zway, ZWBYTE statusId);
ZWSTR _zway_lookup_lock_event_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_lookup_zwave_plus_role_name(ZWay zway, ZWBYTE roleId);
ZWSTR _zway_lookup_alarm_type_name(ZWay zway, ZWBYTE typeId);
ZWSTR _zway_lookup_alarm_event_name(ZWay zway, ZWBYTE typeId, ZWBYTE eventId);
ZWBOOL _zway_lookup_alarm_event_is_state(ZWay zway, ZWBYTE typeId, ZWBYTE eventId);
int _zway_lookup_alarm_event_opposite_to(ZWay zway, ZWBYTE typeId, ZWBYTE eventId);
ZWSTR _zway_lookup_color_capability_name(ZWay zway, ZWBYTE capabilityId);
ZWSTR _zway_lookup_barrier_signal_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_lookup_indicator_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_lookup_indicator_property_name(ZWay zway, ZWBYTE id);
ZWSTR _zway_lookup_user_code_name(ZWay zway, const char *type, ZWBYTE id);
ZWSTR _zway_lookup_door_lock_mode_name(ZWay zway, ZWBYTE mode);
ZWSTR _zway_lookup_door_lock_operation_type_name(ZWay zway, ZWBYTE operationType);

#if defined(__ZWAY_STATIC_CONFIGURATION__)
#include "ZWayConfigurationDefaults.h"
#endif

inline static int _zway_configuration_get_defaults_autoconfig(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Autoconfig.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Autoconfig");
#endif
}

inline static int _zway_configuration_get_defaults_deep_interview(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.DeepInterview.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/DeepInterview");
#endif
}

inline static int _zway_configuration_get_defaults_deep_save_data_after_interview_steps(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SaveDataAfterInterviewSteps.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/SaveDataAfterInterviewSteps");
#endif
}

inline static int _zway_configuration_get_defaults_secure_interview_accepted_without_scheme_inherit(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SecureInterviewAcceptedWithoutSchemeInherit.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/SecureInterviewAcceptedWithoutSchemeInherit");
#endif
}

inline static int _zway_configuration_get_defaults_secure_all_ccs(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SecureAllCCs.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/SecureAllCCs");
#endif
}

inline static int _zway_configuration_get_defaults_device_reply_timeout(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.DeviceReplyTimeout.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/DeviceReplyTimeout");
#endif
}

inline static int _zway_configuration_get_defaults_device_relax_delay(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.DeviceRelaxDelay.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 5, "/Defaults/DeviceRelaxDelay");
#endif
}

inline static float _zway_configuration_get_defaults_serial_api_timeout(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SerialAPITimeout.value;
    (void)zway;
#else
    return _xpath_select_float(zway->xml.defaults, 0.0f, "/Defaults/SerialAPITimeout");
#endif
}

inline static int _zway_configuration_get_defaults_long_range(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.LongRange.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/LongRange");
#endif
}

static inline int _zway_configuration_get_defaults_save_config_type(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SaveConfigType.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/SaveConfigType");
#endif
}

static inline ZWBOOL _zway_configuration_get_defaults_save_config_separate(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.SaveConfigSeparate.value;
    (void)zway;
#else
    return _xpath_select_boolean(zway->xml.defaults, FALSE, "/Defaults/SaveConfigSeparate");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_wakeup_keep_me_informed_instead_of_sis(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.Wakeup.KeepMeInformedInsteadOfSIS.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/Wakeup/KeepMeInformedInsteadOfSIS");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_wakeup_wakeup_interval(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.Wakeup.WakeupInterval.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/Wakeup/WakeupInterval");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_wakeup_wakeup_with_wakeup_on_demand(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.Wakeup.WakeupIntervalWithWakeupOnDemand.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/Wakeup/WakeupIntervalWithWakeupOnDemand");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_association_always_do_association_interview(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.Association.AlwaysDoAssociationInterview.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/Association/AlwaysDoAssociationInterview");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_central_scene_max_scenes(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.CentralScene.MaxScenes.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 16, "/Defaults/CommandClass/CentralScene/MaxScenes");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_scene_controller_conf_max_scenes(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.SceneControllerConf.MaxScenes.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 16, "/Defaults/CommandClass/SceneControllerConf/MaxScenes");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_protection_mode(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.Protection.Mode.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/Protection/Mode");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_sensor_multilevel_fahrenheit(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.SensorMultilevel.Fahrenheit.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/SensorMultilevel/Fahrenheit");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_switch_all_mode(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.SwitchAll.Mode.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/CommandClass/SwitchAll/Mode");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_multi_cmd_max_num(ZWay zway, int default_value)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.MultiCmd.MaxNum.value;
    (void)default_value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, default_value, "/Defaults/CommandClass/MultiCmd/MaxNum");
#endif
}

inline static int _zway_configuration_get_defaults_comand_class_firmware_update_fragment_size(ZWay zway, int default_value)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.CommandClass.FirmwareUpdate.FragmentSize.value;
    (void)default_value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, default_value, "/Defaults/CommandClass/FirmwareUpdate/FragmentSize");
#endif
}

inline static int _zway_configuration_get_defaults_controller_app_version_major(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.AppVersion.Major.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/AppVersion/Major");
#endif
}

inline static int _zway_configuration_get_defaults_controller_app_version_minor(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.AppVersion.Minor.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/AppVersion/Minor");
#endif
}

inline static int _zway_configuration_get_defaults_controller_hardware_version(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.HardwareVersion.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/HardwareVersion");
#endif
}

inline static int _zway_configuration_get_defaults_controller_manufacturer_specific_vendor_id(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.ManufacturerSpecific.VendorID.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/ManufacturerSpecific/VendorID");
#endif
}

inline static int _zway_configuration_get_defaults_controller_manufacturer_specific_product_id(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.ManufacturerSpecific.ProductID.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/ManufacturerSpecific/ProductID");
#endif
}

inline static int _zway_configuration_get_defaults_controller_manufacturer_specific_product_type_id(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.ManufacturerSpecific.ProductTypeID.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/ManufacturerSpecific/ProductTypeID");
#endif
}

inline static int _zway_configuration_get_defaults_controller_specific_device_class(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.SpecificDeviceClass.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/SpecificDeviceClass");
#endif
}

inline static int _zway_configuration_get_defaults_controller_generic_device_class(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.GenericDeviceClass.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/GenericDeviceClass");
#endif
}

inline static int _zway_configuration_get_defaults_controller_icons_installer_icon(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Icons.InstallerIcon.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Icons/InstallerIcon");
#endif
}

inline static int _zway_configuration_get_defaults_controller_icons_user_icon(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Icons.UserIcon.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Icons/UserIcon");
#endif
}

inline static int _zway_configuration_get_defaults_controller_lifeline_max_nodes(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Lifeline.MaxNodes.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 1, "/Defaults/Controller/Lifeline/MaxNodes");
#endif
}

inline static int _zway_configuration_get_defaults_controller_channels_number(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Channels.Number.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Channels/Number");
#endif
}

inline static int _zway_configuration_get_defaults_controller_channels_specific_device_class(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Channels.SpecificDeviceClass.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Channels/SpecificDeviceClass");
#endif
}

inline static int _zway_configuration_get_defaults_controller_channels_generic_device_class(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Channels.GenericDeviceClass.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Channels/GenericDeviceClass");
#endif
}

inline static int _zway_configuration_get_defaults_controller_channels_icons_installer_icon(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Channels.Icons.InstallerIcon.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Channels/Icons/InstallerIcon");
#endif
}

inline static int _zway_configuration_get_defaults_controller_channels_icons_user_icon(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return _ZWayConfigurationDefaults.Defaults.Controller.Channels.Icons.UserIcon.value;
    (void)zway;
#else
    return _xpath_select_integer(zway->xml.defaults, 0, "/Defaults/Controller/Channels/Icons/UserIcon");
#endif
}

inline static ZWSTR _zway_configuration_get_defaults_controller_node_information_frame(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return zassert(strdup(_ZWayConfigurationDefaults.Defaults.Controller.NodeInformationFrame.value));
    (void)zway;
#else
    return _xpath_select_string(zway->xml.defaults, "/Defaults/Controller/NodeInformationFrame");
#endif
}

inline static ZWSTR _zway_configuration_get_defaults_controller_setters_command_classes_list(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return zassert(strdup(_ZWayConfigurationDefaults.Defaults.Controller.SettersCommandClassesList.value));
    (void)zway;
#else
    return _xpath_select_string(zway->xml.defaults, "/Defaults/Controller/SettersCommandClassesList");
#endif
}

inline static ZWSTR _zway_configuration_get_defaults_controller_channels_node_information_frame(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return zassert(strdup(_ZWayConfigurationDefaults.Defaults.Controller.Channels.NodeInformationFrame.value));
    (void)zway;
#else
    return _xpath_select_string(zway->xml.defaults, "/Defaults/Controller/Channels/NodeInformationFrame");
#endif
}

inline static ZWSTR _zway_configuration_get_defaults_controller_name(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return zassert(strdup(_ZWayConfigurationDefaults.Defaults.Controller.Name.value));
    (void)zway;
#else
    return _xpath_select_string(zway->xml.defaults, "/Defaults/Controller/Name");
#endif
}

inline static ZWSTR _zway_configuration_get_defaults_controller_location(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return zassert(strdup(_ZWayConfigurationDefaults.Defaults.Controller.Location.value));
    (void)zway;
#else
    return _xpath_select_string(zway->xml.defaults, "/Defaults/Controller/Location");
#endif
}

inline static ZWBOOL _zway_configuration_get_defaults_try_to_be_come_sis(ZWay zway)
{
#if defined(__ZWAY_STATIC_CONFIGURATION__)
    return (_ZWayConfigurationDefaults.Defaults.TryToBecomeSIS.value == 0) ? FALSE : TRUE;
    (void)zway;
#else
    if (zway->xml.defaults == NULL)
    {
        return FALSE;
    }
    return _xpath_select_boolean(zway->xml.defaults, FALSE, "/Defaults/TryToBecomeSIS");
#endif
}

#endif//zway_configuration_privat_h