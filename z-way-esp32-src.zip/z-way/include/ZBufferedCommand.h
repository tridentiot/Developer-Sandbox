//
//  ZBufferedCommand.h
//  z-way
//
//  Created by Alex Skalozub on 31/07/14.
//
//  Copyright (c) 2014 Z-Wave.Me
//

#ifndef zway_command_buffer_h
#define zway_command_buffer_h

struct _ZBufferedCommand
{
    ZWBOOL is_bridge;
    ZWBYTE *data;
    ZWBYTE length;
    struct _ZBufferedCommand *next;
};

void _zway_process_buffered_commands(ZWay zway);

#endif
