//
//  ZCommandList.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 2/4/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_command_list_h
#define zway_command_list_h

struct _ZCommandListEntry
{
    ZCommand command;
    ZCommandListEntry next;
};

struct _ZCommandList
{
    ZCommandListEntry first;
    ZCommandListEntry last;
    size_t count;
    ZTIME_T update_time;
};

// create a new command list
ZCommandList _zway_command_list_create();

// deallocate command list and all its members
void _zway_command_list_free(const ZWay zway, ZCommandList list);

// add a new command to list
void _zway_command_list_append(const ZWay zway, ZCommandList list, ZCommand command);

// remove command from list (by pointer)
void _zway_command_list_remove(const ZWay zway, ZCommandList list, ZCommand command);

// remove command from list (by id)
void _zway_command_list_remove_by_id(const ZWay zway, ZCommandList list, ZWBYTE id);

// return a command pointer for specified id, or NULL if not found
ZCommand _zway_command_list_get_by_id(const ZWay zway, const ZCommandList list, ZWBYTE id);

#endif
