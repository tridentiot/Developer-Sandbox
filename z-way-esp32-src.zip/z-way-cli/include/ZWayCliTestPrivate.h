#ifndef zway_cli_test_private_h
#define zway_cli_test_private_h

#include "ZDefsPublic.h"

ZWError _zway_cli_test_memory(ZWay zway);
ZWError _zway_cli_test_save(ZWay zway);
ZWError _zway_cli_test_restore(ZWay zway);

#endif // zway_cli_test_private_h