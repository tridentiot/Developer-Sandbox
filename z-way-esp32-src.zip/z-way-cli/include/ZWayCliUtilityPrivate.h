#ifndef zway_cli_utility_private_h
#define zway_cli_utility_private_h

#include "ZDefsPublic.h"

ZWError _zway_cli_utility_set_default(ZWay zway);
ZWError _zway_cli_utility_set_freq(ZWay zway, ZWCSTR region);

#endif // zway_cli_utility_private_h