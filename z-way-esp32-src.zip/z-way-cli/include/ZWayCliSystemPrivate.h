#ifndef zway_cli_system_private_h
#define zway_cli_system_private_h

#include "ZDefsPublic.h"

ZWError _zway_cli_system(ZWCSTR cmd_buffer);

#endif // zway_cli_system_private_h