#ifndef zway_cli_print_private_h
#define zway_cli_print_private_h

#include "ZDefsPublic.h"

#define ZWAY_CLI_CMD_SYSTEM "system"
#define ZWAY_CLI_CMD_SYSTEM_TASK "task"
#define ZWAY_CLI_CMD_SYSTEM_TASK_INFO "info"

void _zway_cli_print_help(ZWCSTR add_help);
void _zway_cli_print_basic_holder(const ZDataRootObject root, ZWDataChangeType type, ZDataHolder data, void *UNUSED(arg));
void _zway_cli_print_dump_data_holder(const ZWay zway, ZDataHolder data);
ZWEXPORT_PRIVATE void _zway_cli_print_zway_terminated(ZWay zway, void *UNUSED(arg));
ZWEXPORT_PRIVATE void _zway_cli_print_d_i_cc_event(const ZWay zway, ZWDeviceChangeType type, ZWNODE node_id, ZWBYTE instance_id, ZWBYTE command_id, void *UNUSED(arg));

#endif // zway_cli_print_private_h