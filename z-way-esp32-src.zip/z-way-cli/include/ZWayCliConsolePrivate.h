#ifndef ZWAY_CLI_CONSOLE_H
#define ZWAY_CLI_CONSOLE_H

#include "ZDefsPublic.h"

ZWError _zway_cli_console_deinit(void);
ZWError _zway_cli_console_init(void);
ZWSTR _zway_cli_console_get_input(void);

#endif // ZWAY_CLI_CONSOLE_H