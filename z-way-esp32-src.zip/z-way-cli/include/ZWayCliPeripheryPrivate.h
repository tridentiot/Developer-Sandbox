#ifndef zway_cli_periphery_private_h
#define zway_cli_periphery_private_h

#include "ZDefsPublic.h"

ZWError _zway_cli_periphery_fs_init(void);

#endif // zway_cli_periphery_private_h