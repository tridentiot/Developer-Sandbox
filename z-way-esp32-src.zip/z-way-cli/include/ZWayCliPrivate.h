#ifndef zway_cli_private_h
#define zway_cli_private_h

#include "ZDefsPublic.h"

typedef ZWBOOL (*_zway_cli_process_add_parse)(ZWCSTR buffer);

ZWEXPORT_PRIVATE ZWError _zway_cli_process(ZWay zway, ZWCSTR add_help, _zway_cli_process_add_parse parse);

#define ZWAY_CLI_MAX_INPUT_BUFFER 0x100

#endif // zway_cli_private_h