//
//  ZSerializeCommonParsePrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 08.10.2024.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_common_parse_private_h
#define zserialize_common_parse_private_h

#include "ZPlatform.h"
#include "ZLog.h"
#include <regex.h>

ZWEXPORT_PRIVATE ZWBOOL _zserialize_common_parse_command_match(ZWSTR input, ZWCSTR pattern, regmatch_t *m, size_t argc);
static inline ZWBOOL _zserialize_common_parse_command_contains(ZWCSTR input, ZWCSTR cmd, size_t length)
{
    if (strncmp(input, cmd, length) != 0)
    {
        return FALSE;
    }
    return TRUE;
}

typedef ZWBYTE _z_serialize_commonParse_arguments_type_t;
typedef enum _ZSerializeCommonParseArgumentsType_e
{
    _ZSerializeCommonParseArgumentsTypeNull = 0,
    _ZSerializeCommonParseArgumentsTypeBoolean,
    _ZSerializeCommonParseArgumentsTypeString,
    _ZSerializeCommonParseArgumentsTypeByte,
    _ZSerializeCommonParseArgumentsTypeWord,
    _ZSerializeCommonParseArgumentsTypeDword,
    _ZSerializeCommonParseArgumentsTypeInteger,
    _ZSerializeCommonParseArgumentsTypeFloat,
    _ZSerializeCommonParseArgumentsTypeBinaryArray,
    _ZSerializeCommonParseArgumentsTypeWordArray,
    _ZSerializeCommonParseArgumentsTypeDwordArray,
    _ZSerializeCommonParseArgumentsTypeIntegerArray,
    _ZSerializeCommonParseArgumentsTypeFloatArray,
    _ZSerializeCommonParseArgumentsTypeStringArray,
} _ZSerializeCommonParseArgumentsType_t;

typedef union _ZSerializeCommonParseArgumentsValue_s
{
    ZWDWORD dwordValue;
    ZWWORD wordValue;
    ZWBYTE byteValue;
    int intValue;
    float floatValue;
    ZWSTR strValue;
    ZWBOOL boolValue;
    int *intArrayValue;
    ZWBYTE *binaryArrayValue;
    ZWWORD *wordArrayValue;
    ZWDWORD *dwordArrayValue;
    float *floatArrayValue;
    ZWSTR *strArrayValue;
    void *ptr;
} _ZSerializeCommonParseArgumentsValue_t;

typedef struct _ZSerializeCommonParseArgumentsContainer_s
{
    _ZSerializeCommonParseArgumentsValue_t value;
    size_t length;
    _ZSerializeCommonParseArgumentsType_t type : 4;
    ZWBOOL allocated;
} _ZSerializeCommonParseArgumentsContainer_t;

typedef struct _ZSerializeCommonParseArgumentsResult_s
{
    _ZSerializeCommonParseArgumentsContainer_t container;
    ZWCSTR nextParams;
} _ZSerializeCommonParseArgumentsResult_t;

ZWBOOL _zserialize_common_parse_arguments_is_type_array(const _ZSerializeCommonParseArgumentsType_t type);
ZWBOOL _zserialize_common_parse_arguments_is_type_array_size(const _ZSerializeCommonParseArgumentsType_t type);
ZWBOOL _zserialize_common_parse_arguments_set_type_array(_ZSerializeCommonParseArgumentsContainer_t *const container, const _ZSerializeCommonParseArgumentsType_t type, const ZWDWORD value);

ZWEXPORT_PRIVATE ZWCSTR _zserialize_common_parse_arguments_skip_spaces(const ZWCSTR params);
ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_arguments(const ZWLog log, ZWCSTR params, _ZSerializeCommonParseArgumentsResult_t *const result, const _ZSerializeCommonParseArgumentsType_t target);
ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_arguments_detecting(ZWCSTR params, _ZSerializeCommonParseArgumentsResult_t *const result);
ZWEXPORT_PRIVATE ZWError _zserialize_common_parse_arguments_packs(const ZWLog log, ZWCSTR params, _ZSerializeCommonParseArgumentsContainer_t *const container, _z_serialize_commonParse_arguments_type_t const *target, const size_t n);
ZWEXPORT_PRIVATE void _zserialize_common_parse_arguments_free(_ZSerializeCommonParseArgumentsContainer_t *const result);
ZWEXPORT_PRIVATE void _zserialize_common_parse_arguments_free_containers(_ZSerializeCommonParseArgumentsContainer_t *const container, const size_t n);
ZWEXPORT_PRIVATE void _zserialize_common_parse_arguments_set_default_containers(_ZSerializeCommonParseArgumentsContainer_t *const container, const size_t n);

#endif // zserialize_common_parse_private_h
