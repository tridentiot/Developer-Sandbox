//
//  ZSerializeZWayCustomFCPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

// Wrappers to match the prefix required for automatic generator of function table
// All functions listed here are not FC functions
// The _fc prefix is used since it is also on the top-level like other FC calls, and automation requires them to have the same prefix

#ifndef zserialize_zway_custom_fc_private_h
#define zserialize_zway_custom_fc_private_h

// Request Stop Zway thread
//
// @JSName: stop
//
// @param: zway
// ZWay object instance
//
// @param: successCallback
// @default: NULL
// Custom function to be called on function success
// NULL if callback is not needed
//
// @param: failureCallback
// @default: NULL
// Custom function to be called on function failure
// NULL if callback is not needed
//
// @param: callbackArg
// Custom argument to be passed to custom function to be called on function success or failure
//
ZWError _zway_fc_stop(ZWay zway, ZJobCustomCallback successCallback, ZJobCustomCallback failureCallback, void *callbackArg);

// Request Log level Set
//
// @JSName: logLevelSet
//
// @param: zway
// ZWay object instance
//
// @param: level
// Log level
//
// @param: successCallback
// @default: NULL
// Custom function to be called on function success
// NULL if callback is not needed
//
// @param: failureCallback
// @default: NULL
// Custom function to be called on function failure
// NULL if callback is not needed
//
// @param: callbackArg
// Custom argument to be passed to custom function to be called on function success or failure
//
ZWError _zway_fc_log_level_set(ZWay zway, ZWBYTE level, ZJobCustomCallback successCallback, ZJobCustomCallback failureCallback, void *callbackArg);

#endif // zserialize_zway_custom_fc_private_h
