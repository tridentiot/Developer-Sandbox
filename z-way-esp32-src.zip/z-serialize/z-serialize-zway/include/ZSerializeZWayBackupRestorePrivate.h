//
//  ZSerializeZWayBackupRestorePrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 16.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_zway_backup_restore_private_h
#define zserialize_zway_backup_restore_private_h

#include "ZWayLib.h"
#include "ZStreamPrivate.h"

ZWEXPORT_PRIVATE ZWBOOL _zserialize_zway_is_command_backup(const ZWCSTR in);
ZWEXPORT_PRIVATE ZWBOOL _zserialize_zway_is_command_restore(const ZWCSTR in, ZWBOOL *const p_force);

ZWEXPORT_PRIVATE ZWError _zserialize_zway_backup(const ZWay zway, const _ZStreamHttpWrite_t *const stream, void *const ctx_stream);
#endif // zserialize_zway_backup_restore_private_h
