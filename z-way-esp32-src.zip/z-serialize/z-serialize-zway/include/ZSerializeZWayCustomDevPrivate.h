//
//  ZSerializeZwayCustomDevPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

// Wrappers to match the prefix required for automatic generator of function tabled
// Some static inline functions might be converted to simple static functions, but we don't care about it

#ifndef zserialize_zway_custom_dev_private_h
#define zserialize_zway_custom_dev_private_h

// Send NoOperation to a node and wake up it's queue.
// Used to explicitelly check if mains powered is reachable or the battery device is currently awake and mark it as failed if not reachable (after this it is possible to do RemoveFailed).
//
// @JSName: SendNoOperation
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_send_nop(const ZWay zway, const ZWNODE device_id)
{
    return zway_device_send_nop(zway, device_id, NULL, NULL, NULL);
};

// Force queue wakeup for a device
// Try to deliver jobs in the queue for the specified device.
// Note that jobs in the queue might be marked again as W (wait for wakeup) after first unsuccessful delivery.
//
// @JSName: WakeupQueue
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_awake_queue(const ZWay zway, const ZWNODE device_id)
{
    zway_device_awake_queue(zway, device_id);
    return NoError;
};

// Force re-interview of the device.
// Deletes Command Class and Instance structures,
// renders them from scratch based on NIF and mandatory Command Claasses and
// runs interview.
//
// @JSName: InterviewForce
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_interview_force(const ZWay zway, const ZWNODE device_id)
{
    return zway_device_interview_force(zway, device_id);
};

// Request NIF of a device
//
// @JSName: RequestNodeInformation
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_request_node_information(const ZWay zway, const ZWNODE device_id)
{
    return zway_fc_request_node_information(zway, device_id, NULL, NULL, NULL);
};

// Request neighbours update for specific node
//
// @JSName: RequestNodeNeighbourUpdate
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_request_node_neighbour_update(const ZWay zway, const ZWNODE device_id)
{
    return zway_fc_request_node_neighbour_update(zway, device_id, NULL, NULL, NULL);
};

// Remove a failed node
// Checks that the node is failed by sending a NOP and removes it
//
// @JSName: RemoveFailedNode
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_remove_failed_node(const ZWay zway, const ZWNODE device_id)
{
    return zway_controller_remove_failed_node(zway, device_id);
};

// Loads Device Description XML (ZDDX) file for specified device
//
// @JSName: LoadXMLFile
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
// @param: file_name
// XML file name
//
static inline ZWError __zway_dev_load_xml(const ZWay zway, const ZWNODE device_id, ZWCSTR file_name)
{
    return zway_device_load_xml(zway, device_id, file_name);
};

TODO(GuessXML)

// Assigns return route to a device.
// Use this function instead of directly calling Function Class AssignReturnRoute
// since this function also handles controller/slave difference.
//
// @JSName: AssignReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
// @param: node_id
// Node Id of the device to save the route to
//
static inline ZWError __zway_dev_assign_return_route(const ZWay zway, const ZWNODE device_id, const ZWNODE node_id)
{
    return zway_device_assign_return_route(zway, device_id, node_id);
};

// Assigns priority return route to a device.
// Use this function instead of directly calling Function Class AssignPriorityReturnRoute
// since this function also handles controller/slave difference.
//
// @JSName: AssignPriorityReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
// @param: node_id
// Node Id of the device to save the route to
//
// @param: repeater1
// Node Id of the first repeater in the path. 0 means direct path. 0xff in all fields means don't use user defined route
//
// @param: repeater2
// Node Id of the second repeater in the path. 0 means one hop. 0xff in all fields means don't use user defined route
//
// @param: repeater3
// Node Id of the third repeater in the path. 0 means two hops. 0xff in all fields means don't use user defined route
//
// @param: repeater4
// Node Id of the fourth repeater in the path. 0 means three hops. 0xff in all fields means don't use user defined route
//
static inline ZWError __zway_dev_assign_priority_return_route(const ZWay zway, const ZWNODE device_id, const ZWNODE node_id, const ZWBYTE repeater1, const ZWBYTE repeater2, const ZWBYTE repeater3, const ZWBYTE repeater4)
{
    return zway_device_assign_priority_return_route(zway, device_id, node_id, repeater1, repeater2, repeater3, repeater4);
};

// Deletes ALL return route in device
// Use this function instead of directly calling Function Class DeleteReturnRoute
// since this function also handles controller/slave difference
//
// @JSName: DeleteReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_delete_return_route(const ZWay zway, const ZWNODE device_id)
{
    return zway_device_delete_return_route(zway, device_id);
};

// Assigns SUC return route to a device
// Use this function instead of directly calling Function Class AssignSUCReturnRoute
// since this function also handles controller/slave difference
//
// @JSName: AssignSUCReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_assign_suc_return_route(const ZWay zway, const ZWNODE device_id)
{
    return zway_device_assign_suc_return_route(zway, device_id);
};

// Assigns priority SUC return route to a device
// Use this function instead of directly calling Function Class AssignPrioritySUCReturnRoute
// since this function also handles controller/slave difference
//
// @JSName: AssignPrioritySUCReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
// @param: repeater1
// Node Id of the first repeater in the path. 0 means direct path. 0xff in all fields means don't use user defined route
//
// @param: repeater2
// Node Id of the second repeater in the path. 0 means one hop. 0xff in all fields means don't use user defined route
//
// @param: repeater3
// Node Id of the third repeater in the path. 0 means two hops. 0xff in all fields means don't use user defined route
//
// @param: repeater4
// Node Id of the fourth repeater in the path. 0 means three hops. 0xff in all fields means don't use user defined route
//
static inline ZWError __zway_dev_assign_priority_suc_return_route(const ZWay zway, const ZWNODE device_id, const ZWBYTE repeater1, const ZWBYTE repeater2, const ZWBYTE repeater3, const ZWBYTE repeater4)
{
    return zway_device_assign_priority_suc_return_route(zway, device_id, repeater1, repeater2, repeater3, repeater4);
};

// Set Static Update Controller (SUC) in the network and inform other devices about the assignment.
// Use this function instead of directly calling Function Class SetSUCNodeId
// since this function handles EnableSUC and SendSUCNodeId/AssignSUCReturnRoute calls.
//
// @JSName: DeleteSUCReturnRoute
//
// @param: zway
// ZWay object instance
//
// @param: device_id
// Node Id
//
static inline ZWError __zway_dev_delete_suc_return_route(const ZWay zway, const ZWNODE device_id)
{
    return zway_device_delete_suc_return_route(zway, device_id);
};

#endif // zserialize_zway_custom_dev_private_h
