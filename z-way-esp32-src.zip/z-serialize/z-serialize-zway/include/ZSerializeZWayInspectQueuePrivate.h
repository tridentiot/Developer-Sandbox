//
//  ZSerializeZWayInspectQueuePrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 16.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zserialize_zway_inspect_queue_private_h
#define zserialize_zway_inspect_queue_private_h

#include "ZWayLib.h"
#include "ZSerializeCommonPrivate.h"
#include "ZSerializeDownloadPrivate.h"

ZWEXPORT_PRIVATE ZWError _zserialize_zway_inspect_queue(_ZSerializeCommonCtx_t *const serialize);

#endif // zserialize_zway_inspect_queue_private_h
