//
//  ZSerializeZwayCustomCtrlPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

// Wrappers to match the prefix required for automatic generator of function table
// Some static inline functions might be converted to simple static functions, but we don't care about it

#ifndef zserialize_zway_custom_ctrl_private_h
#define zserialize_zway_custom_ctrl_private_h

// Start/stop Inclusion of a new node
// Available on primary and inclusion controllers
//
// @JSName: AddNodeToNetwork
//
// @param: zway
// ZWay object instance
//
// @param: startStop
// Start inclusion mode if True, stop if False
//
static inline ZWError __zway_ctrl_add_node_to_network(const ZWay zway, const ZWBOOL startStop)
{
    return zway_controller_add_node_to_network(zway, startStop);
};

// Start/stop exclusion of a node
// Note that this function can be used to exclude a device from previous network before including in ours.
// Available on primary and inclusion controllers
// 
// @JSName: RemoveNodeFromNetwork
//
// @param: zway
// ZWay object instance
//
// @param: startStop
// Start inclusion mode if True, stop if False
//
static inline ZWError __zway_ctrl_remove_node_from_network(const ZWay zway, const ZWBOOL startStop)
{
    return zway_controller_remove_node_from_network(zway, startStop);
};

// Remove a failed node
// Checks that the node is failed by sending a NOP and removes it
// 
// @JSName: RemoveFailedNode
//
// @param: zway
// ZWay object instance
//
// @param: nodeId
// Node ID to be removed
//
static inline ZWError __zway_ctrl_remove_failed_node(const ZWay zway, const ZWNODE nodeId)
{
    return zway_controller_remove_failed_node(zway, nodeId);
};

// Set new primary controller (also known as Controller Shift)
// Same as Inclusion, but the newly included device will get the role of primary.
// Available only on primary controller.
// 
// @JSName: ControllerChange
//
// @param: zway
// ZWay object instance
//
// @param: startStop
// Start create new primary mode if True, stop if False
//
static inline ZWError __zway_ctrl_controller_change(const ZWay zway, const ZWBOOL startStop)
{
    return zway_controller_change(zway, startStop);
};

// Request SUC Node Id
//
// @JSName: GetSUCNodeId
//
// @param: zway
// ZWay object instance
//
static inline ZWError __zway_ctrl_get_suc_node_id(const ZWay zway)
{
    return zway_fc_get_suc_node_id(zway, NULL, NULL, NULL);
};

// Set Static Update Controller (SUC) in the network and inform other devices about the assignment.
// Use this function instead of directly calling Function Class SetSUCNodeId
// since this function handles EnableSUC and SendSUCNodeId/AssignSUCReturnRoute calls.
// 
// @JSName: SetSUCNodeId
//
// @param: zway
// ZWay object instance
//
// @param: nodeId
// Node Id to be come the new SUC
//
static inline ZWError __zway_ctrl_set_suc_node_id(const ZWay zway, const ZWNODE nodeId)
{
    return zway_controller_set_suc_node_id(zway, nodeId);
};

// Set SUC ID Server (SIS) in the network and inform other devices about the assignment.
// Use this function instead of directly calling Function Class SetSUCNodeId
// since this function handles EnableSUC/EnableSIS and SendSUCNodeId/AssignSUCReturnRoute calls.
//
// @JSName: SetSISNodeId
//
// @param: zway
// ZWay object instance
//
// @param: nodeId
// Node Id to be come the new SIS
//
static inline ZWError __zway_ctrl_set_sis_node_id(const ZWay zway, const ZWNODE nodeId)
{
    return zway_controller_set_sis_node_id(zway, nodeId);
};

// Disable SUC/SIS in the network and inform other devices about the assignment.
// Use this function instead of directly calling Function Class SetSUCNodeId
// since this function handles DisableSUC and SendSUCNodeId/DeleteSUCReturnRoute calls.
//
// @JSName: DisableSUCNodeId
//
// @param: zway
// ZWay object instance
//
// @param: nodeId
// Node Id to revoke SUC/SIS role from
//
static inline ZWError __zway_ctrl_disable_suc_node_id(const ZWay zway, const ZWNODE nodeId)
{
    return zway_controller_disable_suc_node_id(zway, nodeId);
};

// Send NIF of the stick
//
// @JSName: SendNodeInformation
//
// @param: zway
// ZWay object instance
//
// @param: nodeId
// @default: 255
// Destination Node Id (NODE_BROADCAST to send non-routed broadcast packet)
//
static inline ZWError __zway_ctrl_send_node_information(const ZWay zway, const ZWNODE nodeId)
{
    return zway_fc_send_node_information(zway, nodeId, NULL, NULL, NULL);
};

// Reset the controller
// Note: this function will delete ALL data from the Z-Wave chip and restore it to factory default !
// Sticks based on 4.5x and 6.x SDKs will also generate a new Home Id.
//
// @JSName: SetDefault
//
// @param: zway
// ZWay object instance
//
static inline ZWError __zway_ctrl_set_default(const ZWay zway)
{
    return zway_controller_set_default(zway);
};

// Request network topology update from SUC/SIS
// Note that this process may also fail due more than 64 changes from last sync. In this case a re-inclusion of the controller (self) is required.
//
// @JSName: RequestNetworkUpdate
//
// @param: zway
// ZWay object instance
//
ZWError _zway_ctrl_request_network_update(const ZWay zway);

// Set/stop Learn mode
// Tries first classical inclusion then falls back to NWI automatically.
//
// @JSName: SetLearnMode
//
// @param: zway
// ZWay object instance
//
// @param: startStop
// Start Learn mode if True, stop if False.
//
static inline ZWError __zway_ctrl_set_learn_mode(const ZWay zway, const ZWBOOL startStop)
{
    return zway_controller_set_learn_mode(zway, startStop);
};

// Adds QR to DSKList
//
// @JSName: NodeProvisioningQRAdd
//
// @param: zway
// Z-Way object instance
//
// @param: qr
// QR string
//
// @param: givenName
// @default: NULL
// Given name to set to this device after inclusion
//
// @param: enabled
// @default: TRUE
// Enable (TRUE) or disable (FALSE) the record after adding
//
// @param: lrDefaultEnabled
// @default: TRUE
// Enable (TRUE) or disable (FALSE) Long Range inclusion by default (for LR-capable device)
//
static inline ZWError __zway_ctrl_node_provisioning_qr_add(const ZWay zway, const ZWCSTR qr, const ZWCSTR givenName, const ZWBOOL enabled, const ZWBOOL lrDefaultEnabled)
{
    return zway_node_provisioning_qr_add(zway, qr, givenName, enabled, lrDefaultEnabled);
};

// Removes QR from DSKList
//
// @JSName: NodeProvisioningQRRemove
//
// @param: zway
// ZWay object instance
//
// @param: qr
// QR string
//
static inline ZWError __zway_ctrl_node_provisioning_qr_remove(const ZWay zway, const ZWCSTR qr)
{
    return zway_node_provisioning_qr_remove(zway, qr);
};

#endif // zserialize_zway_custom_ctrl_private_h
