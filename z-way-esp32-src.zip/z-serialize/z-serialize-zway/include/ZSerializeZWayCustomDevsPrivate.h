//
//  ZSerializeZwayCustomDevsPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha on 19.06.2025.
//
//  Copyright (c) 2025 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

// Wrappers to match the prefix required for automatic generator of function tabled
// Some static inline functions might be converted to simple static functions, but we don't care about it

#ifndef zserialize_zway_custom_devs_private_h
#define zserialize_zway_custom_devs_private_h

// Save all Z-Way data to the disc
// This function runs after each step of interview (configurable in Defaults.xml) and
// at Z-Wave library termination
//
// @JSName: SaveData
//
// @param: zway
// ZWay object instance
//
static inline ZWError __zway_devs_zddx_save_to_xml(const ZWay zway)
{
    return zddx_save_to_xml(zway);
}

#endif // zserialize_zway_custom_devs_private_h
