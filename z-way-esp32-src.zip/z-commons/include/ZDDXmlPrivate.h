//
//  ZDDXmlPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zddxml_private_h
#define zddxml_private_h

#include "ZDDXml.h"

ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_init(ZEncoder_t **encoder, const _ZStreamWriter_t *const stream, void *const ctx_stream, ZEncoderDecoderType_t type);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_end(ZEncoder_t *encoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_create_map(ZEncoder_t *encoder, ZEncoderDecoderName_t name, size_t field_count);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_close_map(ZEncoder_t *encoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_create_sub(ZEncoder_t *encoder, size_t count);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_close_sub(ZEncoder_t *encoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_strngz(ZEncoder_t *encoder, ZEncoderDecoderField_t field, ZWCSTR value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_int(ZEncoder_t *encoder, ZEncoderDecoderField_t field, ZWLONGINT64 value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_uint(ZEncoder_t *encoder, ZEncoderDecoderField_t field, ZWDWORD64 value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_special_id_for_commands(ZEncoder_t *encoder, ZWWORD value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_data_holder(ZEncoder_t *encoder, ZDataValue *value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_field_data_holder_name(ZEncoder_t *encoder, const ZDataHolder value);

ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_init(ZDecoder_t **const decoder, const ZDataRootObject root, const _ZStreamReader_t *const stream, void *const ctx_stream, const ZEncoderDecoderType_t type);
ZWEXPORT_PRIVATE void _zddx_decoder_end(ZDecoder_t *decoder);
ZWEXPORT_PRIVATE ZWBOOL _zddx_decoder_element_next(ZDecoder_t *decoder);
ZWEXPORT_PRIVATE size_t _zddx_decoder_get_element_level(ZDecoder_t *const decoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_element_end(ZDecoder_t *const decoder);
ZWEXPORT_PRIVATE ZEncoderDecoderName_t _zddx_decoder_element_name(ZDecoder_t *decoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_field_uint(ZDecoder_t *decoder, ZEncoderDecoderField_t field, ZWDWORD64 *id);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_element_sub(ZDecoder_t *decoder);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_field_stringz(ZDecoder_t *decoder, ZEncoderDecoderField_t field, ZWSTR *out);
ZWEXPORT_PRIVATE void _zddx_decoder_free_data(ZDecoder_t *decoder, void *data);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_field_data_holder(ZDecoder_t *decoder, ZDataValue *value);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_decoder_field_data_holder_name(ZDecoder_t *decoder, ZWSTR *name);

ZWEXPORT_PRIVATE ZDataHolder _zddx_decoder_load_data_holder(ZDecoder_t *const decoder, ZDataHolder realRoot, const ZDataHolder newRoot);
ZWEXPORT_PRIVATE ZEncoderDecoderStatus_t _zddx_encoder_save_data_holder(ZEncoder_t *const encoder, const ZDataHolder data);

#endif//zddxml_private_h
