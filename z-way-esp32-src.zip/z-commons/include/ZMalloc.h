//
//  ZMalloc.c
//  Part of Z-Way.C library
//
//  Created by Poltorak Serguei on 10/19/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_malloc_h
#define zway_malloc_h

#include "ZPlatform.h"

#include <stdio.h> // should be after ZPlatform.h to make sure GNU_SOURCE is defined

#ifndef ZASSERT
#if !defined(__ESP32__)
#define ZASSERT 1 // we always want to have asserts
#endif
#endif // ZASSERT

#if DEBUG_MALLOC

#define zmalloc(size)	_zmalloc(size, __FILE__, __LINE__)
#define zrealloc(ptr, size)	_zrealloc(ptr, size, __FILE__, __LINE__)
#define zfree(ptr)		_zfree(ptr, __FILE__, __LINE__)
#define zstrdup(s)      _zstrdup(s)

ZWEXPORT void _malloc_log_write(PRINTF_FORMAT_STRING const char *format, ...) __printflike(1, 2);

ZWEXPORT void *_zmalloc(size_t size, const char *file, int line);
ZWEXPORT void *_zrealloc(void *ptr, size_t size, const char *file, int line);
ZWEXPORT void _zfree(void *ptr, const char *file, int line);
ZWEXPORT char *_zstrdup(const char *s);

#else

#define zmalloc(size)	malloc(size)
#define zrealloc(ptr, size)	realloc(ptr, size)
#define zfree(ptr)		free(ptr)
#define zstrdup(s)	strdup(s)

#endif // DEBUG_MALLOC

#if ZASSERT

#if DEBUG

#ifdef __cplusplus

template <typename T>
static T _zassert(T ptr, const char *op, const char *file, int line)
{
    if (ptr != NULL) return ptr;
    
    fprintf(stderr, "Got NULL from %s at %s:%u\n", op, file, line);
    #if DEBUG_MALLOC
    _malloc_log_write("Got NULL from %s at %s:%u\n", op, file, line);
    #endif
    
    return NULL;
}

#endif

ZWEXPORT_PRIVATE void *_zassert(void *ptr, const char *op, const char *file, int line);

#define zassert(ptr)    _zassert(ptr, #ptr, __FILE__, __LINE__)

#else

#ifdef __cplusplus

template <typename T>
static T _zassert(T ptr, const char *op)
{
    if (ptr != NULL) return ptr;
    
    fprintf(stderr, "Got NULL from %s\n", op);
    
    return NULL;
}

#endif

ZWEXPORT_PRIVATE void *_zassert(void *ptr, const char *op);

#define zassert(ptr)    _zassert(ptr, #ptr)

#endif // DEBUG

#else

#define zassert(ptr)    ptr

#endif // ZASSERT

ZWEXPORT_PRIVATE ssize_t _zvasprintf(ZWSTR *ptr, PRINTF_FORMAT_STRING ZWCSTR format, va_list ap) __printflike(2, 0);
ZWEXPORT_PRIVATE ssize_t _zasprintf(ZWSTR *ptr, PRINTF_FORMAT_STRING ZWCSTR format, ...) __printflike(2, 3);

ZWEXPORT_PRIVATE void _zmalloc_free_array_of_string(ZWSTR *const string_array, const size_t count);

#endif // zway_malloc_h


