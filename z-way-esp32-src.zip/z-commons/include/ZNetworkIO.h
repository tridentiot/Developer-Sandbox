//
//  ZNetwork.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 5/6/24.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef znetwork_h
#define znetwork_h

#include <netinet/in.h>

#include "ZPlatform.h"
#include "ZLog.h"

ZWEXPORT_PRIVATE uint16_t znio_get_free_port(void);

#endif
