//
//  ZTimerPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//
//  Copyright (c) 2021 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef ztimer_private_h
#define ztimer_private_h

#include <signal.h>

#include "ZPlatform.h"
#include "ZLogPrivate.h"
#include "ZThread.h"

typedef void (*_ZTimerCallback)(void *const root, void *const arg);

typedef struct _ZTimer_s
{
    ZWTIMEMS target_time_ms;
    struct _ZTimer_s *next_sibling;
    void *arg;
    _ZTimerCallback callback;
    _ZTimerCallback cancelCallback;
} _ZTimer_t;

typedef struct _ZTimerCtx_s
{
    ZWLog log;
    void *root;
    ZWMUTEX timers_mutex;
    _ZTimer_t *first_timer;
} _ZTimerCtx_t;

ZWEXPORT_PRIVATE ZWError _ztimer_init(_ZTimerCtx_t **const p_ctx, const ZWLog log, void *const root);
ZWEXPORT_PRIVATE ZWError _ztimer_remove(_ZTimerCtx_t *const ctx, _ZTimer_t *const timer);
ZWEXPORT_PRIVATE ZWError _ztimer_fire(_ZTimerCtx_t *const ctx, _ZTimer_t *const timer);
ZWEXPORT_PRIVATE void _ztimer_deinit(_ZTimerCtx_t *const ctx);
ZWEXPORT_PRIVATE ZWError _ztimer_create(_ZTimerCtx_t *const ctx, _ZTimer_t **const p_timer, ZWDWORD timeout_ms, void *const arg, const _ZTimerCallback callback, const _ZTimerCallback cancelCallback);
ZWEXPORT_PRIVATE void _ztimer_loop(_ZTimerCtx_t *const ctx);

#endif // ztimer_private_h