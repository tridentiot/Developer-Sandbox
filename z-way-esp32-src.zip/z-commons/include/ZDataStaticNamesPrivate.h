//
//  ZDataStaticNamesPrivate.h
//  Part of Z-Way.C library
//
//  Created by Serguei Poltorak on 11/17/24.
//
//  Copyright (c) 2024 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zdata_static_names_private_h
#define zdata_static_names_private_h

#include "ZPlatform.h"
#include "ZDataPrivate.h"

#if defined(ZWAY_ZDATA_STATIC_NAMES)

#define ZDATA_STATIC_NAME_INVALID_VALUE 0 //Use to check if the function could not find anything

#ifdef __cplusplus
extern "C" {
#endif

ZWCSTR _zdata_static_names_get_string(const ZDataRootObject root, const _zhash_murmur_t hash);
_zhash_murmur_t _zdata_static_names_get_hash(const ZDataRootObject root, const ZWCSTR name, const size_t length);

#ifdef __cplusplus
}
#endif

#endif

#endif // zdata_static_names_private_h
