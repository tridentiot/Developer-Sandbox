//
//  ZBLESerial.h
//  Part of Z-Way.C library
//
//  Created by Alexander Polyakov and Poltorak Serguei on 11/01/19.
//
//  Copyright (c) 2019 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifdef _BLE_ZWAY_TRANSPORT

#ifndef     BLE_SERIAL
#define     BLE_SERIAL 
#include    <stdio.h>
#include    <stdint.h>

#include "ZLog.h"
#include "ZSerialIO.h"
#include "ZMalloc.h"

#define     MAX_BLE_ADDR            48
#define     MAX_BLE_RXBUFF          1024 // Maximum receiving buffer size
#define     MAX_BLE_HANDLES         3    // Maximum amount of simultenious BLE connections
#define     MAX_BLE_ADAPTER_NAME    255
#define     MAX_BLE_DEV_NAME        64
#define     MAX_BLE_CHUNK_PAYLOAD   19
#define     MAX_BLE_CHUNK           (MAX_BLE_CHUNK_PAYLOAD+1)
#define     SAPI_CMD_MAX_LEN        150

#define     BLE_SCAN_TIMEOUT        10 // Network scan timeout in the seconds


// Main BLE service parameters
// FIXME: !!! HARCODED. Do we need the ability to modify them in the feature?
// -----------------------------------------------------------------------------
#define BLE_DEFAULT_DEVNAME          "ZW2BLE Bridge"
#define BLE_DEFAULT_UARTSERVICE_UUID "aece2705-c7a0-4751-8167-e4682d6378a8"
#define BLE_DEFAULT_UARTTX_UUID      "a1e27754-d895-422e-9cc1-f456eb99a6ab"
#define BLE_DEFAULT_UARTRX_UUID      "097a1ba8-f75b-4bcc-a063-a7060e7ee28e"
// -----------------------------------------------------------------------------

#define BLE_NAME_PREFIX "ble:"

int zble_open(ZWLog log, const char * name, ZWHANDLE handle);
int zble_availiable(ZWHANDLE handle);
int zble_read(ZWHANDLE handle, uint8_t * buff, size_t  sz);
int zble_write(ZWHANDLE handle, uint8_t * buff, size_t  sz);
void zble_close(ZWHANDLE handle);

#endif      // BLE_SERIAL

#endif
