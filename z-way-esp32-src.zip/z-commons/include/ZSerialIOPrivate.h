//
//  ZSerialIO.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 1/9/12.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zway_serial_io_private_h
#define zway_serial_io_private_h

#include "ZPlatform.h"
#include "ZLog.h"
#include "ZSerialIO.h"

ZWEXPORT_PRIVATE ZWBOOL _zio_port_settings_check(ZWLog logger, const ZIoPortSettings_t settings);
ZWEXPORT_PRIVATE ZWBOOL _zio_port_settings_copy(const ZIoPortSettings_t settings_old, ZIoPortSettings_t *settings_new);
ZWEXPORT_PRIVATE ZWCSTR _zio_port_settings_get_name(const ZIoPortSettings_t settings);
ZWEXPORT_PRIVATE void _zio_port_settings_delete(ZIoPortSettings_t *settings);

#endif // zway_serial_io_private_h
