//
//  ZUrlPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//
//  Copyright (c) 2021 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zurl_private_h
#define zurl_private_h

#include "ZPlatform.h"
#include "ZLogPrivate.h"

ZWEXPORT_PRIVATE ZWError _zurl_decode(ZWLog logger, ZWCSTR url, ZWSTR *output);

#endif // zurl_private_h