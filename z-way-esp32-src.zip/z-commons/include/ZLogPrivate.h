//
//  ZLogPrivate.h
//  Part of Z-Way.C library
//
//  Created by Alex Skalozub on 11/03/14.
//  Based on Z-Way source code written by Christian Paetz and Poltorak Serguei
//
//  Copyright (c) 2012 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef zlog_private_h
#define zlog_private_h

#include "ZPlatform.h"
#include "ZLog.h"

struct _ZWLog {
    FILE* file;
    ZWLogLevel level;
    ZWMUTEX mutex;
    ZWBOOL syslog;
#if defined(__MACH__)
    aslclient asl;
#endif
};

ZWEXPORT_PRIVATE void zlog_write_v(ZWLog log, ZWCSTR source, ZWLogLevel level, PRINTF_FORMAT_STRING ZWCSTR message, va_list arg);
ZWEXPORT_PRIVATE ZWError _zlog_change_level(const ZWLog log, const ZWLogLevel level);
static inline ZWLogLevel _zlog_get_log_level(const ZWLog log)
{
    return log->level;
};

#endif
