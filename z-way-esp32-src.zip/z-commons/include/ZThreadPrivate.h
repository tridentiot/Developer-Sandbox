//
//  ZThreadPrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//
//  Copyright (c) 2021 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//
#ifndef zthread_private_h
#define zthread_private_h

#include "ZLogPrivate.h"
#include "ZThread.h"

ZWEXPORT_PRIVATE void _zthread_feed_watchdog_and_yield(const ZWLog log);

#endif // zthread_private_h
