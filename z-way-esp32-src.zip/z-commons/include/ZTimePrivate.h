//
//  ZTimePrivate.h
//  Part of Z-Way.C library
//
//  Created by Pavel Kulaha.
//
//  Copyright (c) 2021 Z-Wave.Me
//  All rights reserved
//  info@z-wave.me
//
//  This source file is subject to the terms and conditions of the
//  Z-Wave.Me Software License Agreement which restricts the manner
//  in which it may be used.
//

#ifndef ztime_private_h
#define ztime_private_h

#include "ZPlatform.h"
#include "ZLogPrivate.h"

#ifdef __cplusplus
extern "C" {
#endif

ZWEXPORT_PRIVATE ZWError _ztime_get_system_startup_ms(const ZWLog log, ZWTIMEMS *const ms);
ZWEXPORT_PRIVATE ZWError _ztime_get_tz_info(const ZWLog log, const int year, int *const offset, int *const dstOffset, ZWBYTE *const dstStartMonth, ZWBYTE *const dstStartDay, ZWBYTE *const dstStartHour, ZWBYTE *const dstEndMonth, ZWBYTE *const dstEndDay, ZWBYTE *const dstEndHour);
ZWEXPORT_PRIVATE void _ztime_get_local_time(struct tm *const hosttime, int *const msec);
ZWEXPORT_PRIVATE ZWTIMEMS _ztime_get_local_time_ms(void);

#ifdef __cplusplus
}
#endif

#endif // ztime_private_h