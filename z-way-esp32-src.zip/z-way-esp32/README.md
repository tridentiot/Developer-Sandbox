# Getting started
```
    git clone git@github.com:tridentiot/z-way.git &&
    git checkout ESPPort &&
    git submodule update --init --recurisve
```
# How to build Z-Way-ESP32
## Using VSCode IDE ##
1. Install VS Code IDE
2. Install ESP IDF Plugin for VSCode from Plugin store
3. Install ESP IDF platform using menu command *View->Command palleted...->ESP IDF:Configure ESP IDF Extension*. Currently we use v5.3.1 version of IDF.
4. Open z-way-esp32 project folder using menu command *File->Open Folder..*
5. Create IDF configuration for your system using menu command *View->Command palleted...->ESP IDF:Add vscode Configuration folder*
6. Set Espressif device target using status bar ("chip" icon)
7. Start build, flash and monitor action using "fire" icon from status bar
## Using esp_builder.py srcipt ##
1. Install needed OS packages:
  ```
  sudo apt-get install git wget flex bison gperf python3 python3-pip python3-venv cmake ninja-build ccache libffi-dev libssl-dev dfu-util libusb-1.0-0
  ```
2. Install ESP-IDF
   ```
    mkdir -p ~/esp
    cd ~/esp
    git clone -b v5.3.1 --recursive https://github.com/espressif/esp-idf.git
   ```
3. Install tools (compiler/parttable/debugger)
    ```
    cd ~/esp/esp-idf
    ./install.sh all
    ```
5. Go to the working directory
   ```
   cd z-way/z-way-esp32
   ```
6. Build firmware for the all devices
  ```
  python3 py_scripts/esp_builder.py build -s ./ -b tmpbuild1
  ```
# How to flash Z-Way-ESP32 to ESP32 chip/module
## Using native ESP tools ##
1. Open ESP python environment folder (in most case it's located at *~/.espressif/python_env/idf5.3_py3.8_env/bin*) in terminal application 
2. Unzip zip-archive with z-way-esp32 executable into any folder. Remember its path (*path/to/extracted_archive*). 
3. Connect your ESP board to your computer
4. Find its serial port name/tty name (*<esp32 port/tty>*)
5. Run in terminal application the command:
```
python -m esptool --chip esp32 -b 460800 --before default_reset --after hard_reset  --port <esp32 port/tty> write_flash --flash_mode dio --flash_size detect --flash_freq 40m 0x1000 path/to/extracted_archive/bootloader.bin 0x10000 path/to/extracted_archive/z-way-esp32.bin 0x8000  path/to/extracted_archive/partition-table.bin 
```
## Using esp_builder script ##
1. Open terminal inside the *z-way-esp32* folder
2. Connect your ESP board to your computer
3. Find its serial port name/tty name (*<esp32 port/tty>*)
4. Run:
```
python3 py_scripts/esp_builder.py flash <firmware_file.zip> -p <esp32 port/tty>
```
# How to connect to ESP32 console
## Using native ESP tools ##
1. Open ESP python environment folder (in most case it's located at *~/.espressif/python_env/idf5.3_py3.8_env/bin*) in terminal application
2. Find your esp_idf folder (generally ~/esp/v5.3.1/esp-idf/)
3. Connect your ESP board to your computer
4. Find its serial port name/tty name (*<esp32 port/tty>*)
5. Run (to select the right baudrate for -b key use the table below)
```
/python ~/esp/v5.3.1/esp-idf/tools/idf_monitor.py <esp32 port/tty> -b 921600
```
## Using esp_builder script ##
1. Open terminal inside the *z-way-esp32* folder
2. Connect your ESP board to your computer
3. Find its serial port name/tty name (*<esp32 port/tty>*)
4. Run (to select the right baudrate for -b key use the table below):
```
python3 py_scripts/esp_builder.py monitor -p <esp32 port/tty> -b 921600
```
# Debugging
We commonly use detailed logging for debugging purposes. In most complex cases we use JTAG debugging. We recommend Espressif ESP Prog board (based on FTDI 2232 chip) as JTAG adapter. We use VSCode with installed IDF plugin as debugging shell.
## Using JTAG adapter ##
1. Install latest FTDI driver from FTDI site.
2. On MacOS you need to disable apple driver after FTDI driver installation. Open terminal and type:
```
sudo kextunload -b com.apple.DriverKit-AppleUSBFTDI
```
3. Connect your board to JTAG adapter. You need at least 4 wires (+ common GND, + power supply):
```
    JTAG TDI -> ESP GPIO12
    JTAG TCK -> ESP GPIO13
    JTAG TMS -> ESP GPIO14
    JTAG TDO -> ESP GPIO15
```
4. Try to open OpenOCD manually from the VSCode terminal first and check that connections is right:
```
  > openocd -d2 -f board/esp32-wrover-kit-3.3v.cfg
```
If you see something like:
```
Info : auto-selecting first available session transport "jtag". To override use 'transport select <transport>'.
Info : Listening on port 6666 for tcl connections
Info : Listening on port 4444 for telnet connections
Info : ftdi: if you experience problems at higher adapter clocks, try the command "ftdi tdo_sample_edge falling"
Info : clock speed 20000 kHz
Error: JTAG scan chain interrogation failed: all zeroes
Error: Check JTAG interface, timings, target power, etc.
Error: Trying to use configured scan chain anyway...
Error: esp32.cpu0: IR capture error; saw 0x00 not 0x01
```
check your connectivity (point 3) once more.
The right output is 
```
Info : auto-selecting first available session transport "jtag". To override use 'transport select <transport>'.
Info : Listening on port 6666 for tcl connections
Info : Listening on port 4444 for telnet connections
Info : ftdi: if you experience problems at higher adapter clocks, try the command "ftdi tdo_sample_edge falling"
Info : clock speed 20000 kHz
Info : JTAG tap: esp32.cpu0 tap/device found: 0x120034e5 (mfg: 0x272 (Tensilica), part: 0x2003, ver: 0x1)
Info : JTAG tap: esp32.cpu1 tap/device found: 0x120034e5 (mfg: 0x272 (Tensilica), part: 0x2003, ver: 0x1)
Info : [esp32.cpu0] Examination succeed
Info : [esp32.cpu1] Examination succeed
Info : starting gdb server for esp32.cpu0 on 3333
Info : Listening on port 3333 for gdb connections
Info : [esp32.cpu0] Debug controller was reset.
Info : [esp32.cpu0] Core was reset.
Info : [esp32.cpu1] Debug controller was reset.
Info : [esp32.cpu1] Core was reset.
Info : [esp32.cpu0] Target halted, PC=0x401E86A5, debug_reason=00000000
Info : [esp32.cpu0] Reset cause (1) - (Power on reset)
Info : [esp32.cpu1] Target halted, PC=0x4008E6BE, debug_reason=00000000
Info : [esp32.cpu1] Reset cause (14) - (CPU1 reset by CPU0)
Info : accepting 'gdb' connection on tcp/3333
Info : [esp32.cpu0] Target halted, PC=0x4008E6BE, debug_reason=00000000
Info : Set GDB target to 'esp32.cpu0'
Info : [esp32.cpu1] Target halted, PC=0x4008E6BE, debug_reason=00000000
Warn : No symbols for FreeRTOS!
Info : [esp32.cpu0] Target halted, PC=0x400BE65A, debug_reason=00000001
Info : Flash mapping 0: 0x10020 -> 0x3f400020, 1558 KB
Info : Flash mapping 1: 0x1a0020 -> 0x400d0020, 1167 KB
```
Press Ctrl+C to stop manually launched OpenOCD.

5. Click on debug icon in VSCode status bar. This should lead to the correct launch of the debugging interface.
# Hardware requirements
This project can run without external RAM, but in this case you can include only 1-2 slave devices. For normal functionality 2MB+ of external of RAM is needed. In most cases user is able to add an external PSRAM to module, but the integrated solution is more stable and cost effective. 
If you need an OTA functionality for ESP firmware we recommend you to use 16MB of Flash RAM. You can find below the table of compatibility. We don't have build for ESP32S2 at this moment, but we can add on demand. There is no ability to run z-way on RISC-based ESP chips (such as C5/C3/C2/H2 series).
## ESP32 modules support ##
|Module name|Chip type|Suitable target name|External Flash|External RAM|Discription|
|-----------------|-----------------|---------|---------|---------|-----------------------------|
|ESP32-S3-WROOM-1-N4R2|esp32s3|dev-esp32s3|4MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N8R2|esp32s3|dev-esp32s3|8MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. More flash memory for storage. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N16R2|esp32s3|dev-esp32s3|16MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N4R8|esp32s3|dev-esp32s3|4MB|8MB|More PSRAM for user application. Modern LX7 Core. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N8R8|esp32s3|dev-esp32s3|16MB|8MB|More PSRAM for user application. Modern LX7 Core. More flash memory for storage. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N16R8|esp32s3|dev-esp32s3|16MB|8MB|More PSRAM for user application. Modern LX7 Core. The biggest flash memory for the user code and storage. Built in PCB antenna.|
|ESP32-S3-WROOM-1-N16R16|esp32s3|dev-esp32s3|16MB|16MB|The biggest available PSRAM for the user application. Modern LX7 Core. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-S3-WROOM-1U-N4R2|esp32s3|dev-esp32s3|4MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N8R2|esp32s3|dev-esp32s3|8MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. More flash memory for storage. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N16R2|esp32s3|dev-esp32s3|16MB|2MB|Minimal PSRAM for Z-Wave support is included. Modern LX7 Core. The biggest flash memory for user code and storage.  External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N4R8|esp32s3|dev-esp32s3|4MB|8MB|More PSRAM for user application. Modern LX7 Core. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N8R8|esp32s3|dev-esp32s3|8MB|8MB|More PSRAM for user application. Modern LX7 Core. More flash memory for storage.  External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N16R8|esp32s3|dev-esp32s3|16MB|8MB|More PSRAM for user application. Modern LX7 Core. The biggest flash memory for the user code and storage. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N16R16|esp32s3|dev-esp32s3|16MB|16MB|The biggest available PSRAM for the user application. Modern LX7 Core. The biggest flash memory for user code and storage.  External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1-N4|esp32s3|ext. mem.: dev-esp32s3|4MB|-|No PSRAM for Z-Wave support is included.  User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core.  Built in PCB antenna|
|ESP32-S3-WROOM-1-N8|esp32s3|ext. mem.: dev-esp32s3|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core.  Built in PCB antenna.|
|ESP32-S3-WROOM-1-N16|esp32s3|ext. mem.: dev-esp32s3|16MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core. The biggest flash memory for user code and storage.  Built in PCB antenna.|
|ESP32-S3-WROOM-1U-N4|esp32s3|-|4MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N8|esp32s3|ext. mem.: dev-esp32s3|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core. More flash memory for storage. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-S3-WROOM-1U-N16|esp32s3|ext. mem.: dev-esp32s3|16MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Modern LX7 Core. The biggest flash memory for user code and storage.  External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-WROOM-32E-N4R2|esp32|dev-esp32|4MB|2MB|Minimal PSRAM for Z-Wave support is included. Built in PCB antenna.|
|ESP32-WROOM-32E-N8R2|esp32|prod-esp32N8R2|8MB|2MB|Minimal PSRAM for Z-Wave support is included. More flash memory for storage. Built in PCB antenna.|
|ESP32-WROOM-32E-N16R2|esp32|prod-esp32N8R2|16MB|2MB|Minimal PSRAM for Z-Wave support is included. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-WROOM-32UE-N4R2|esp32|dev-esp32|4MB|2MB|Minimal PSRAM for Z-Wave support is included. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-WROOM-32UE-N8R2|esp32|prod-esp32N8R2|8MB|2MB|Minimal PSRAM for Z-Wave support is included. More flash memory for storage. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-WROOM-32UE-N16R2|esp32|prod-esp32N8R2|16MB|2MB|Minimal PSRAM for Z-Wave support is included. The biggest flash memory for user code and storage. External antenna (u.fl/ipex connector). Compact PCB placement.|
|ESP32-WROOM-32E-N4|esp32|dev-esp32|4MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Built in PCB antenna.|
|ESP32-WROOM-32E-N8|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. More flash memory for storage. Built in PCB antenna.|
|ESP32-WROOM-32E-N16|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|16MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-WROOM-32E-H4|esp32|dev-esp32|4MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Built in PCB antenna.|
|ESP32-WROOM-32E-H8|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. Built in PCB antenna.|
ESP32-WROOM-32UE-N4|esp32|dev-esp32|4MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. External antenna (u.fl/ipex connector).|
|ESP32-WROOM-32UE-N8|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. More flash memory for storage. External antenna (u.fl/ipex connector).|
|ESP32-WROOM-32UE-N16|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|16MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. The biggest flash memory for user code and storage. External antenna (u.fl/ipex connector).|
|ESP32-WROOM-32UE-H4|esp32|dev-esp32|4MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. External antenna (u.fl/ipex connector).|
|ESP32-WROOM-32UE-H8|esp32|dev-esp32 ext.mem.: prod-esp32N8R2|8MB|-|No PSRAM for Z-Wave support is included. User should add external RAM manually. This is a possible cause of instability and errors. We do not recommend this solution. External antenna (u.fl/ipex connector).|
|ESP32-WROVER-E-N4R2|esp32|dev-wrov1|4MB|2MB|Minimal PSRAM for Z-Wave support is included. Built in PCB antenna.|
|ESP32-WROVER-E-N8R2|esp32|dev-wrov1|8MB|2MB|Minimal PSRAM for Z-Wave support is included. More flash memory for storage. Built in PCB antenna.|
|ESP32-WROVER-E-N16R2|esp32|dev-wrov1|16MB|2MB|Minimal PSRAM for Z-Wave support is included. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-WROVER-E-N4R8|esp32|dev-wrov1|4MB|8MB|More PSRAM for user application. Built in PCB antenna.|
|ESP32-WROVER-E-N8R8|esp32|dev-wrov1|8MB|8MB|More PSRAM for user application. More flash memory for storage. Built in PCB antenna.|
|ESP32-WROVER-E-N16R8|esp32|dev-wrov1|16MB|8MB|More PSRAM for user application. The biggest flash memory for user code and storage. Built in PCB antenna.|
|ESP32-WROVER-IE-N4R2|esp32|dev-wrov1|4MB|2MB|Minimal PSRAM for Z-Wave support is included. Built in PCB antenna.|
|ESP32-WROVER-IE-N8R2|esp32|dev-wrov1|8MB|2MB|Minimal PSRAM for Z-Wave support is included. More flash memory for storage. Built in PCB antenna.|
|ESP32-WROVER-IE-N16R2|esp32|dev-wrov1|16MB|2MB|Minimal PSRAM for Z-Wave support is included. The biggest flash memory for user code and storage. The same PCB, but the external antenna (u.fl/ipex) connector is mounted.|
|ESP32-WROVER-IE-N4R8|esp32|dev-wrov1|4MB|8MB|More PSRAM for user application. Built in PCB antenna.|
|ESP32-WROVER-IE-N8R8|esp32|dev-wrov1|8MB|8MB|More PSRAM for user application. More flash memory for storage. The same PCB, but the external antenna (u.fl/ipex) connector is mounted.|
|ESP32-WROVER-IE-N16R8|esp32|dev-wrov1|16MB|8MB|More PSRAM for user application. The biggest flash memory for user code and storage. The same PCB, but the external antenna (u.fl/ipex) connector is mounted.|

# Build variants
 You can see The full list inside the *zway_targets.json*.
 If you see that pull is needed for the button pin then you have to connect 100K resistor between button pin and 3v3 power pin for board startup.
 |Device name|Chip type|Memory size (Flash/RAM)|UART Pins|Button|Console baudrate|Descriptions|
 |-----------------|---------|-----------------|---------|---------|------------|-----------------------------|
 |dev-esp32|esp32|4/-|TX:18 RX:19|pin:5|921600|Any standard WROOM module|
 |dev-esp32s3|esp32s3|8(16)/8|TX:18 RX:17|pin:5|921600|New generation of WROOM modules based on esp32s3|
 |dev-wrov1|esp32|4/8|TX:18 RX:19|pin:34,pullup is needed|460800|ESP32 WROVER module|
 |prod-esp32N8R2|esp32|8(16)/2|TX:18 RX:19|pin:34,pullup is needed|921600|Trident board based on ESP32WROOM8R2 or ESP32WROOM16R2|
## How to define new build variant ##
To define a new build variant one should do these steps:
+ Add new default configuration inside main z-way folder (z-way.c/arch_specific/esp32/cfg/) with name sdkconfig.default.<new_variant>
+ Fill this file according your device configuration (see another files in this directory for the reference)
+ Add a new clause inside the CMake file *z-way-esp32/main/CMakeList.txt* like this:
```
 elseif("${DEVICE}" STREQUAL "<new_variant>")
 set("DEVICE_SPECIFIC_DEFS"

 )
```
+ add UART pin definitions inside the "DEVICE_SPECIFIC_DEFS" using **ESP_UART1_TX=<pinnumber>**, **ESP_UART1_RX=<pinnumber>**
+ add button pin definitions using **ZWAY_ESP32_RESCUE_BTN=<pinnumber>**
+ add new <new_variant> name inside "devices" section of **zway_targets.json**
# Wi-Fi startup
Unconfigured device always starts in SoftAP mode. The SSID is like *ZWAY-ESP-XXXX*, password:**12345678**. After user set Wi-Fi credentials device tries to connect to selected AP. If device is unable to connect to desired AP it goes to SoftAP mode. If user holds the button during device boot SoftAP mode is used.

# How to setup Wi-Fi credentials
1. Using serial console:
```
ZWay> w <SSIDname> <PASSWD>
ZWay> x
```
2. Using http request:
```
192.168.4.1:8083/ZWave/ESP/setWiFiCredentials("<SSIDname>","<PASSWD>")
192.168.4.1:8083/ZWave/ESP/reboot()
```
Note: Board never starts STA mode if you don't connect pullup resistor for some builds. See the table above. 

# Web User Interface
You are able to obtain device's IP address and hostname using mDNS (use the script **python3 py_sripts/test_mdns.py** ). When device starts in SoftAP mode its IP address is always **192.168.4.1** 
```
http://<device_IP>:8083/
or 
http://ZWAY-ESP-<NUMBER>.local:8083/
```
You can also obtain device address by means of **I** CLI command:
```
ZWay> I
```
 

