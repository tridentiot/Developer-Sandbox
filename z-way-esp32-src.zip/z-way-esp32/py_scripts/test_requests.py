import argparse
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import time
import traceback
import requests
import math
from typing import cast
from   zeroconf import ServiceBrowser, ServiceListener, Zeroconf
from threading import Thread, Lock

def loadSourceFile(filename, by_lines = True):
    logging.debug("Loading source file:%s"%(filename))
    source_lines = []
    with open(filename, "r", encoding='utf-8', errors='ignore') as f:
        if(by_lines):
            source_lines = f.readlines()
        else:
            source_lines = f.read()
    return source_lines
def loadJSONData(filename):
    if os.path.isfile(filename):
        ts = time.time()
        text = loadSourceFile(filename, False)
        #md = orjson.loads(text)
        md = json.loads(text)
        print("*** JSON %s load elapsed:%3.3f"%(filename, time.time() - ts))
        return md
    return None 
class MyListener(ServiceListener):
    def __init__(self, addr_holder):
        self.addr_holder = addr_holder
    
    def update_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        print(f"Service {name} updated")

    def remove_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        print(f"Service {name} removed")

    def add_service(self, zc: Zeroconf, type_: str, name: str) -> None:
        info = zc.get_service_info(type_, name)
        print(f"Service {name} added, service info: {info}")
        if info:
            addresses = ["%s:%d" % (addr, cast(int, info.port)) for addr in info.parsed_scoped_addresses()]
            print("  Addresses: %s" % ", ".join(addresses))
            print("  Weight: %d, priority: %d" % (info.weight, info.priority))
            print(f"  Server: {info.server}")
            server_name = "%s"%(info.server)[:-1]
            self.addr_holder += [["%s:%s"%(server_name, info.port), addresses]]
            if info.properties:
                print("  Properties are:")
                for key, value in info.properties.items():
                    print(f"    {key!r}: {value!r}")
            else:
                print("  No properties")

if __name__ == "__main__":
    MY_VERSION = "0.1b1"
    stat_failed =0 
    stat_success=0
    stat_min_time = 0
    stat_max_time = 0
    stat_overall_time = 0
    stat_overall_size = 0

    def dummyFunc(args):
        print("*** Trident IoT. Z-Way Request Test script. Platform:%s Version:%s ***"%(platform.system(), MY_VERSION))
        sys.exit(0)
    def innerRequest(url, tm):
        global stat_failed, stat_success, stat_min_time, stat_max_time, stat_overall_time, stat_overall_size
        print("%5.3f Request:%s tm:%s"%(time.time(), url, tm))
        start_time =  time.time() 
        try:
            response = requests.get(url, timeout=tm)
            dt = time.time() - start_time
            if response.status_code == 200:
                if dt > stat_max_time or stat_max_time == 0:
                    stat_max_time = dt
                if dt < stat_min_time or stat_min_time == 0:
                    stat_min_time = dt
                size = len(response.content)
                print("%5.3f Successful %s. Elapsed:%f. Size:%d Bytes"%(time.time(), url, dt, size))
                stat_success += 1
                stat_overall_time += dt
                stat_overall_size += size
            else:
                print("%5.3f Failed %s. ErrCode:%d Elapsed:%f"%(time.time(), url, response.status_code, dt))
                stat_failed += 1
        except Exception as ex:
            stat_failed += 1
            print("Request exception:%s"%(ex))
        print(" >>> Summary. Successfuly:%d Failed:%d Overall:%d | Time min:%f max:%f overall:%f AVG:%f | Size: AVG:%d overall:%d | AVG Speed:%f"%(stat_success, stat_failed, stat_success+stat_failed, stat_min_time, stat_max_time, stat_overall_time, stat_overall_time/stat_success, stat_overall_size // stat_success, stat_overall_size ,stat_overall_size/stat_overall_time))
   
    
    def runRequest(url, tm, bNonBlock=False):
        if bNonBlock:
            t = Thread(target=innerRequest, args=(url,tm,))
            t.start()
        else:
            innerRequest(url, tm)
    def execRequests(host, reqlst, block):
        for r in reqlst:
            url = "http://" + host +"/"+ r["url"]
            timeout = 50
            if "timeout" in r:
                timeout = r["timeout"]
            runRequest(url, timeout, block == 0)
    def reqFuncTest(args):
        global stat_failed, stat_success, stat_min_time, stat_max_time, stat_overall_time, stat_overall_size
        stat_failed = 0
        stat_success = 0
        stat_min_time = 0
        stat_max_time = 0
        stat_overall_time = 0
        stat_overall_size = 0
        reqdata = loadJSONData(args.file)
        if reqdata == None:
            print("Can't open a JSON file:%s"%(args.file))
            sys.exit(-1) 
            return -1
        host = args.address
        if host == None:
            # Autodetect host using zeroconf
            zeroconf = Zeroconf()
            hosts = []
            listener = MyListener(hosts)
            browser = ServiceBrowser(zeroconf, "_http._tcp.local.", listener)
            print("--- Scanning the network...")
            timeout  = time.time() + 10.0
            while 1:
                for h in hosts:
                    if h[0].startswith("ZWAY-ESP-"):
                        host = h[1][0]
                        break
                if host != None:
                    break
                if time.time() > timeout:
                    break
            zeroconf.close()
            if host == None:
                print("Unable to find Z-Way in ZeroConf hosts!")
                sys.exit(-2) 
        block = 1
        if "blocking" in reqdata:
            block = reqdata["blocking"]
        if "repeat" in reqdata:
            for count in range(reqdata["repeat"]["counter"]):
                execRequests(host, reqdata["requests"], block)
                if "delay" in reqdata["repeat"]:
                    d = reqdata["repeat"]["delay"]
                    time.sleep(d)
            
        else:
            execRequests(host, reqdata["requests"], block)
    def Main():
        parser = argparse.ArgumentParser(description='Z-Way Request Test tool.\n Version:%s\n Welcome :) '%(MY_VERSION))
        parser.set_defaults(func=dummyFunc)
        subparsers = parser.add_subparsers()
        parserReq = subparsers.add_parser('req', help="Sends HTTP request according to specified JSON file")
        parserReq.add_argument('-a', '--address', default=None, help="Use specified URL instead of autodetection")
        parserReq.add_argument('file', default="reqtest.json",help="File contains http request")
        parserReq.set_defaults(func=reqFuncTest)
        args = parser.parse_args()
        args.func(args)
    Main()
    