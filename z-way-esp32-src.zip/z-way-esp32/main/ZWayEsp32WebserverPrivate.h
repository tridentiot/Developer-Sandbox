//
//  ZwayEsp32WebserverPrivate.h
//
//  Created by Alexander Polyakov on 11/10/24
//
//  Copyright (c) 2024 Trident IOT
//
//
#ifndef zway_esp32_webserver_private_h
#define zway_esp32_webserver_private_h

#include "ZPlatform.h"

#include "esp_http_server.h"

#ifndef ZWAY_ESP_WEB_SERVER_PORT
#define ZWAY_ESP_WEB_SERVER_PORT 8083
#endif

typedef struct _ZwayEsp32WebServerCtx_s
{
    httpd_handle_t server;
} _ZwayEsp32WebServerCtx_t;

ZWError _zway_esp32_web_server_start(_ZwayEsp32WebServerCtx_t *ctx, ZWay zway);
ZWError _zway_esp32_web_server_stop(_ZwayEsp32WebServerCtx_t *ctx);

#endif // zway_esp32_webserver_private_h